BEGIN=$(date '+%Y/%m/%d %H:%M')

g++ -o Kron Kron.c -lrt
./Kron $1 $2 ;  notify-send "Finito Kron" 
g++ -o KronBin KronBin.c -lrt
./KronBin $1 $2 ;  notify-send "Finito KronBin" 
g++ -o naive naive.c -lrt
./naive $1 $2 ;  notify-send "Finito naive" 
g++ -o mine mine.c -lrt
./mine $1 $2 ;  notify-send "Finito mine" 
./plotit.m;
notify-send "Finito Tutto" 


END=$(date '+%Y/%m/%d %H:%M')
BODY="Il programma e' terminato con input $1*100 $2*100.\nInizio: $BEGIN\nFine: $END"
echo -e $BODY | mail -A test.png -s "mailme $END" giovanni.barbarino@gmail.com
notify-send "mailme: mail inviata."
    

