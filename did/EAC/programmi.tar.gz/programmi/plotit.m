#!/usr/bin/octave -qf

clf 
data=load("time_kron.txt");
plot (data (:,1), data (:,2), 'r;Kron;', "linewidth", 2); 

hold on;

data=load("time_kronbin.txt");
plot (data (:,1), data (:,2), 'b;KronBin;', "linewidth", 2); 

data=load("time_pow.txt");
plot (data (:,1), data (:,2), 'g;potenze;', "linewidth", 2); 

data=load("time_mine.txt");
plot (data (:,1), data (:,2), 'k;mine;', "linewidth", 2); 

 saveas (1, "test.png");
% print -dpng test.png
% print(h,"test.png",["png"]); 


