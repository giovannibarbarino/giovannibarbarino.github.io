#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>


int tab2[]={0,1,0,-1,0,-1,0,1};

int prime(int n){
	
	if(n==1) return 0;
	if(n<1) {
		printf("\ncoglione! hai chiesto se %d sia primo!\n\n",n);		
		return -1;
		}
	
	int i=2;
	
	while(i<n){
		if(n%i==0)
			return 0;
		i++;
	}
	
	return 1;
	

}



int kron(long int a,long int b){
	
	int v=0,k=1,r;
	
	if(b==0){
		if(a==1 || a==-1) return 1;
		return 0;
	}
	
	if(a==0){
		if(b>1) return 0;
		return 1;
	}
	
	if(a&1==0 && b&1==0) return 0;
	
	if(a&1) for(v=0;b&1==0;v++,b=b>>1);
	
	if(v&1) k=tab2[a&7];
	
	if(b<0){
		b=-b;
		if(a<0) k=-k;		
	}

	for(v=0;a&1==0;v++,a=a>>1);
	
	if(v&1==1) k=tab2[b&7]*k;
	
	if(a&b&2) k=-k;
	
	r=abs(a); 
	a=b%r;
	b=r;
	
	while(1){
		
		if(a==0){
			if(b>1) return 0;
			return k;
		}
		
		for(v=0;a&1==0;v++,a=a>>1);
	
		//assert(b%2!=0);
		//assert(a%2!=0);
	
		if(v&1 && tab2[b&7]==-1) k=-k;
		
		if(a&b&2) k=-k;
	
		r=a; 
		a=b%r;
		b=r;
	}
	
}


// funziona solo con b primo dispari positivo
int test(long int a, long int b, int ris){
	
	long int i,j;
	a=a%b;
	
	assert(b>2);
	assert(prime(b));
	
	if(a==0){
		if (ris==0);  //printf("\nbene, funziona!\n %d su %d fa proprio %d!\n", a,b,ris);
		else   printf("\n1-cazzo, non funziona!\n %ld su %ld non fa %d!\n", a,b,ris);
		return 0;
	}
	
	for(i=1;i<b;i++){
		j=i*i;
		if(a==(j%b)){
			if (ris==1);  //printf("\nbene, funziona!\n %d su %d fa proprio %d!\n", a,b,ris);
			else   printf("\n2-cazzo, non funziona!\n %ld su %ld non fa %d!\n Infatti %ld^2=%ld=%ld mod %ld\n", a,b,ris,i,i*i,a,b);
			return 0;
		}
	}
	
	if (ris==-1);  //printf("\nbene, funziona!\n %d su %d fa proprio %d!\n", a,b,ris);
	else   printf("\n3-cazzo, non funziona!\n %ld su %ld non fa %d!\n", a,b,ris);
	return 0;
	

}




int main (int argc, char* argv[])
{
	
	printf("Elaborazione con l'algoritmo di Kronecker\n");
	
	int n,m;
	n=100; m=1;
	if(argc) n=atoi(argv[1]);
	if(argc==2) m=atoi(argv[2]); 
	
	FILE* graph2;
	
	graph2 = fopen("graph2.txt","w");
	
	long int a,ris,b=3;
	int tr;
	long int tem1,tem2,s,ns;
	long int j,i=1;
	float ab=0;
	
	
	struct timespec start = { 0 };
	struct timespec stop = { 0 };
	
	
	/*
	printf("\nintrodurre un numero primo: ");
	scanf("%d", &p);
	
	while(!prime(p)){
		
		printf("Non è un numero primo!\n");
		printf("\nintrodurre un numero primo: ");
		scanf("%d", &p);
	}
	
	
	a=420;
	b=93827;
	ris=kron(a,b);
	tr=test(a,b,ris);
	*/
	
	
	
	while(i<100*n){
	
		if(prime(b)){
			tem1=0;
			tem2=0;
			ab=0;
			a=0;
			
			clock_gettime(CLOCK_REALTIME, &start);
			
			
			for(j=0;j<100*m;j++){
				a=rand();
				a=a%b;
				
				//a++;
				//if(a==b) a=1;
			
				//clock_gettime(CLOCK_REALTIME, &start);

				ris=kron(a,b);
			
				//clock_gettime(CLOCK_REALTIME, &stop);
				
				//s=-start.tv_sec+stop.tv_sec;
				//ns=-start.tv_nsec+stop.tv_nsec;
				//if(ns>1000 || s) ns=0;
				//tem1+=s;
				//tem2+=ns;
			
			//printf("\nil generatore di %d per il programma è %d\n",p,a);
			//tr=test(a,b,ris);
				//if((j+1)%100==0){
				//	ab+=tem2/100;
					//ab+=tem1*10000000;
					//tem1=0;
				//	tem2=0;
				//}
			//tr=test(a,b,ris);
			}
			
			
			clock_gettime(CLOCK_REALTIME, &stop);
			
			//s=-start.tv_sec+stop.tv_sec;
			//ns=-start.tv_nsec+stop.tv_nsec;
			ab=(-start.tv_nsec+stop.tv_nsec);
			

			ab=ab/(100*m);
			//tem2=tem2+1000*tem1;
			if(ab>0 && 1000>ab)
				fprintf(graph2,"%ld %f\n",i,ab);
			
			i++;
			if(i%(n)==0)
				printf("Siamo al %ld per cento	\n",i/n);
		}
		
		
		b++;
	}
	
	 fclose(graph2);
	
	return 0;

}
