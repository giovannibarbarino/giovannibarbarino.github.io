#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>


int prime(int n){
	
	if(n==1) return 0;
	if(n<1) {
		printf("\ncoglione! hai chiesto se %d sia primo!\n\n",n);		
		return -1;
		}
	
	int i=2;
	
	while(i<n){
		if(n%i==0)
			return 0;
		i++;
	}
	
	return 1;
	

}


// funziona solo con b primo dispari positivo
int test(long int a, long int b, long int ris){
	
	long int i,j;
	a=a%b;
	
	assert(b>2);
	assert(prime(b));
	
	if(a==0){
		if (ris==0);  //printf("\nbene, funziona!\n %d su %d fa proprio %d!\n", a,b,ris);
		else   printf("\n1-cazzo, non funziona!\n %ld su %ld non fa %ld!\n", a,b,ris);
		return 0;
	}
	
	for(i=1;i<b;i++){
		j=i*i;
		if(a==(j%b)){
			if (ris==1);  //printf("\nbene, funziona!\n %d su %d fa proprio %d!\n", a,b,ris);
			else   printf("\n2-cazzo, non funziona!\n %ld su %ld non fa %ld!\n Infatti %ld^2=%ld=%ld mod %ld\n", a,b,ris,i,i*i,a,b);
			return 0;
		}
	}
	
	if (ris==-1);  //printf("\nbene, funziona!\n %d su %d fa proprio %d!\n", a,b,ris);
	else   printf("\n3-cazzo, non funziona!\n %ld su %ld non fa %ld!\n", a,b,ris);
	return 0;
	

}

int powmet(long int a, long int p){
	// calcola a^((p-1)/2) mod p
	if(a==0) return 0;
	
	long int n,y=1;
	n=(p-1)>>1;
	
	if(n==1){
		if(a==1)
			return 1;
		else return -1;
	}
	
	while(n){
		if(n&1){
			y=(y*a)%p;
			n--;
		}
		else{
			a=(a*a)%p;
			n=n>>1;
		}
	}
	
	if(y==1)
		return 1;
	else return -1;
	
	
}


int main (int argc, char* argv[])
{
	
	printf("Elaborazione con l'algoritmo delle potenze\n");
	
	int n,m;
	n=100; m=1;
	if(argc) n=atoi(argv[1]);
	if(argc==2) m=atoi(argv[2]); 
	
	FILE* graph3;
	
	graph3 = fopen("graph3.txt","w");
	
	long int a,ris,b=3;
	long int tem1,tem2,ns,s;
	float ab=0;
	
	long int i=1,j,k;
	
	int tr;
	
	struct timespec start = { 0 };
	struct timespec stop = { 0 };
	
	//time_t seconds;
	//time_t end;
	
	
	
	
	while(i<100*n){
	
		if(prime(b)){
			tem1=0;
			tem2=0;
			ab=0;
			k=0;
			
			a=0;
			
			clock_gettime(CLOCK_REALTIME, &start);
			
			
			for(j=0;j<100*m;j++){
				//a++;
				//if(a==b) a=1;
				
				a=rand();
				a=a%b;
				
				//clock_gettime(CLOCK_REALTIME, &start);

				ris=powmet(a,b);
			
				//clock_gettime(CLOCK_REALTIME, &stop);
				
				//s=-start.tv_sec+stop.tv_sec;
				//ns=-start.tv_nsec+stop.tv_nsec;
				//if(ns>1000 || s) ns=0;
				//tem1+=s;
				//tem2+=ns;
			
			//printf("\nil generatore di %d per il programma è %d\n",p,a);
			//tr=test(a,b,ris);
				//if((j+1)%100==0){
				//	ab+=tem2/100;
					//ab+=tem1*10000000;
					//tem1=0;
				//	tem2=0;
				//}
			//tr=test(a,b,ris);
			}
			
			
			clock_gettime(CLOCK_REALTIME, &stop);
			
			//s=-start.tv_sec+stop.tv_sec;
			//ns=-start.tv_nsec+stop.tv_nsec;
			ab=(-start.tv_nsec+stop.tv_nsec);
			

			ab=ab/(100*m);
			//tem2=tem2+1000*tem1;
			if(ab>0 && 1000>ab)
				fprintf(graph3,"%ld %f\n",i,ab);
			
			
			i++;
			if(i%(n)==0)
				printf("Siamo al %ld per cento	\n",i/n);
		}
		
		
		b++;
	}
	
	
	fclose(graph3);
	
	return 0;

}
