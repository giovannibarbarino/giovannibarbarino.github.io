
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>



FILE *fp;
char *text; //tutto il testo del documento

//servono per segnarsi in che tweet sono le parole
typedef struct _intweet{

	int inizio;
	struct _intweet *next;

	} intweet;
//lettere dei tray delle parole
typedef struct _carattere {

	char lett;
	struct _carattere *fratello;
	struct _carattere *figlio;
	struct _carattere *padre;
	intweet *occorrenze;
	float importanza;
	int tag;
	int num_occorrenze;
	} carattere;
//lettere dei tray degli autori
typedef struct _author {

	char lett;
	struct _author *fratello;
	struct _author *figlio;
	struct _author *padre;
	intweet *scrittore;
	intweet *destinatari;
	int tweet_scritti; // è <100.000
	int tweet_ricevuti; // è <100.000
	} author;
//strutture necessarie per l'array degli inizi dei tweet
typedef struct _address{
	author *fine;
	struct _address *next;
	} address;
typedef struct _parola{
	carattere *fine;
	struct _parola *next;
	int check; //serve per la cancellazione logica
	} parola;
typedef struct _tweet{
	int iniz;
	parola *dentro;
	int tag;
	author *autore;
	address *destinatari;
	} tweet;
// parole della coda di priorità
typedef struct _link {
	float peso;
	struct _carattere* fine;
} link;

carattere *dizionario; //da qui parte il tray delle parole
author *autori; //tray di autori e destinatari
tweet inizio_tweet[100001]; //un'array che riporta gli indici di inizio testo dei tweet,
// parte da 1, e da ogni cella parte la lista di puntatori alle parole
carattere *paroletag[150000]; //lista delle parole taggate
int c=0; //indice delle parole taggate


//mette un carattere in minuscolo
char lowcase(char a){
	if(a>64 && a<91)
		return(a+32);
	return(a);
	}


/* stampa una parola partendo dall'ultimo carattere */
void stampa_parola (carattere *fine){

	if(fine!=NULL){
		if(fine->padre!=dizionario) stampa_parola(fine->padre);
		printf("%c",fine->lett);
	}
}

//manda in stampa il tweet in inizio
void stampa_testo(int numtweet){

	int i=inizio_tweet[numtweet].iniz-1;
	char l=text[i];
	parola *scorri;
	i++;

	while(text[i]!=l){
		if(text[i]=='\\') {
			i++;
			if(97>text[i] || text[i]>122) printf("%c",text[i]);
			else printf(" ");
		}
		else printf("%c",text[i]);
		i++;
	}

	scorri=inizio_tweet[numtweet].dentro;
	while(scorri!=NULL)
	{
		if(scorri->check && scorri->fine->tag)
			{printf(" #"); stampa_parola(scorri->fine);}
		scorri=scorri->next;
	}
	printf("\n");
}

/* stampa una parola partendo dall'ultimo carattere */
void stampa_autore (author *fine){

	if(fine!=NULL){
		if(fine->padre!=autori) stampa_autore(fine->padre);
		printf("%c",fine->lett);
	}
	else
		printf("stai cercando di stampare NULL!\n");
}

/* stampa gli autori, da richiamare con a=autori */
void stampa_autori(author *a){

	author *scorri1=a;

	if(scorri1->scrittore!=NULL){
		stampa_autore(a);
		printf(" (%d)",scorri1->tweet_scritti);
		printf(" \n");
	}

	scorri1=scorri1->figlio;
	while(scorri1!=NULL){
		stampa_autori(scorri1);
		scorri1=scorri1->fratello;
	}
}

/* stampa i destinatari, da richiamare con a=autori */
void stampa_destinatari(author *a){

	author *scorri1=a;

	if(scorri1->destinatari!=NULL){
		stampa_autore(a);
		printf(" (%d)",scorri1->tweet_ricevuti);
		printf(" \n");
	}

	scorri1=scorri1->figlio;
	while(scorri1!=NULL){
		stampa_destinatari(scorri1);
		scorri1=scorri1->fratello;
	}
}

void stampa_tweet_autore(author *origine){

	intweet *scorri=origine->scrittore;
	while(scorri!=NULL){
		stampa_testo(scorri->inizio);
		putchar('\n');
		scorri=scorri->next;
	}
}

void stampa_tweet_destinatario(author *origine){

	intweet *scorri=origine->destinatari;
	while(scorri!=NULL){
		printf("Autore: ");
		stampa_autore(inizio_tweet[scorri->inizio].autore);
		printf("\n");
		stampa_testo(scorri->inizio);
		putchar('\n');
		scorri=scorri->next;
	}
}

void stampa_tweet_parola(carattere *fine){

	intweet *scorri=fine->occorrenze;
	while(scorri!=NULL){

		printf("Autore: ");
		stampa_autore(inizio_tweet[scorri->inizio].autore);
		printf("\n");
		stampa_testo(scorri->inizio);
		putchar('\n');
		scorri=scorri->next;

	}
}

void stampa_hash_autore(author *origine){

	carattere *vis[100000];
	intweet *scorri1;
	parola *scorri2;
	int i,twe,cont=0;

	if(origine!=NULL){
		for(i=0;i<100000;i++) vis[i]=NULL;
		scorri1=origine->scrittore;
		while(scorri1!=NULL){
			twe=scorri1->inizio;
			scorri2=inizio_tweet[twe].dentro;
			while(scorri2!=NULL){
				if(scorri2->check && scorri2->fine->tag && scorri2->fine->tag<9){
					scorri2->fine->tag+=10;
					vis[cont]=scorri2->fine;
					cont++;
					printf("#");
					stampa_parola(scorri2->fine);
					printf("\n");
				}
				scorri2=scorri2->next;
			}
			scorri1=scorri1->next;
		}

		while(cont){
		cont--;
		vis[cont]->tag-=10;
		if(vis[cont]->tag>9 || vis[cont]->tag<0) printf("error!!\n");
		}
	}
}

void stampa_hash_destinatario(author *origine){

	carattere *vis[100000];
	intweet *scorri1;
	parola *scorri2;
	int i,twe,cont=0;

	if(origine!=NULL){
		for(i=0;i<100000;i++) vis[i]=NULL;
		scorri1=origine->destinatari;
		while(scorri1!=NULL){
			twe=scorri1->inizio;
			scorri2=inizio_tweet[twe].dentro;
			while(scorri2!=NULL){
				if(scorri2->check && scorri2->fine->tag && scorri2->fine->tag<9){
					scorri2->fine->tag+=10;
					vis[cont]=scorri2->fine;
					cont++;
					printf("#");
					stampa_parola(scorri2->fine);
					printf("\n");
				}
				scorri2=scorri2->next;
			}
			scorri1=scorri1->next;
		}

		while(cont){
		cont--;
		vis[cont]->tag-=10;
		if(vis[cont]->tag>9 || vis[cont]->tag<0) printf("error!!\n");
		}
	}
}

void stampa_destinatari_autore(author *origine){

	author *vis[100000];
	intweet *scorri1;
	address *scorri2;
	int i,twe,cont=0;

	if(origine!=NULL){
		for(i=0;i<100000;i++) vis[i]=NULL;
		scorri1=origine->scrittore;
		while(scorri1!=NULL){
			twe=scorri1->inizio;
			scorri2=inizio_tweet[twe].destinatari;
			while(scorri2!=NULL){
				if(scorri2->fine->tweet_scritti<100000){
					scorri2->fine->tweet_scritti+=100000;
					vis[cont]=scorri2->fine;
					cont++;
					printf("@");
					stampa_autore(scorri2->fine);
					printf("\n");
				}
				scorri2=scorri2->next;
			}
			scorri1=scorri1->next;
		}

		while(cont){
			cont--;
			vis[cont]->tweet_scritti-=100000;
			if(vis[cont]->tweet_scritti>100000 || vis[cont]->tweet_scritti<0) printf("error!!\n");
		}
	}

}

void stampa_autori_destinatario(author *origine){


	author *vis[100000];
	intweet *scorri1;
	author *scorri2;
	int i,twe,cont=0;

	if(origine!=NULL){
		for(i=0;i<100000;i++) vis[i]=NULL;
		scorri1=origine->destinatari;
		while(scorri1!=NULL){
			twe=scorri1->inizio;
			scorri2=inizio_tweet[twe].autore;
			if(scorri2!=NULL && scorri2->tweet_scritti<100000){
				scorri2->tweet_scritti+=100000;
				vis[cont]=scorri2;
				cont++;
				stampa_autore(scorri2);
				printf("\n");

			}
			scorri1=scorri1->next;
		}

		while(cont){
			cont--;
			vis[cont]->tweet_scritti-=100000;
			if(vis[cont]->tweet_scritti>100000 || vis[cont]->tweet_scritti<0) printf("error!!\n");
		}
	}
}

void stampa_destinatari_hash(carattere *hash){


	author *vis[100000];
	intweet *scorri1;
	address *scorri2;
	int i,twe,cont=0;

	if(hash!=NULL){
		for(i=0;i<100000;i++) vis[i]=NULL;
		scorri1=hash->occorrenze;
		while(scorri1!=NULL){
			twe=scorri1->inizio;
			scorri2=inizio_tweet[twe].destinatari;
			while(scorri2!=NULL){
				if(scorri2->fine->tweet_scritti<100000){
					scorri2->fine->tweet_scritti+=100000;
					vis[cont]=scorri2->fine;
					cont++;
					printf("@");
					stampa_autore(scorri2->fine);
					printf("\n");
				}
				scorri2=scorri2->next;
			}
			scorri1=scorri1->next;
		}

		while(cont){
			cont--;
			vis[cont]->tweet_scritti-=100000;
			if(vis[cont]->tweet_scritti>100000 || vis[cont]->tweet_scritti<0) printf("error!!\n");
		}
	}
}

void stampa_autori_hash(carattere *hash){


	author *vis[100000];
	intweet *scorri1;
	author *scorri2;
	int i,twe,cont=0;

	if(hash!=NULL){
		for(i=0;i<100000;i++) vis[i]=NULL;
		scorri1=hash->occorrenze;
		while(scorri1!=NULL){
			twe=scorri1->inizio;
			scorri2=inizio_tweet[twe].autore;
			if(scorri2!=NULL && scorri2->tweet_scritti<100000){
				scorri2->tweet_scritti+=100000;
				vis[cont]=scorri2;
				cont++;
				stampa_autore(scorri2);
				printf("\n");

			}
			scorri1=scorri1->next;
		}

		while(cont){
			cont--;
			vis[cont]->tweet_scritti-=100000;
			if(vis[cont]->tweet_scritti>100000 || vis[cont]->tweet_scritti<0) printf("error!!\n");
		}
	}
}

void stampa_tweet_autorehash(author *origine,carattere *hash){

	int flag=0;
	intweet *scorri;

	if(hash==NULL) printf("\nl'hashtag immesso non è una parola presente in nessun tweet\n");
	else if (!(hash->tag)) printf("\nla parola immessa non è un'hashtag, ma è presente in qualche tweet. Per cercarla, tornare al menù principale, e selezionare la ricerca per parole\n");
	else{
		scorri=hash->occorrenze;
		while(scorri!=NULL){
			if(inizio_tweet[scorri->inizio].autore==origine){
				stampa_testo(scorri->inizio);
				printf("\n");
				flag=1;
			}
			scorri=scorri->next;
		}
		if(!flag) printf("\nl'autore selezionato non ha mai scritto niente che contenesse questo hashtag, implicito o esplicito\n");
	}
}

void stampa_tweet_destinatariohash(author *origine,carattere *hash){

	int rip=0;
	intweet *scorri1=origine->destinatari;
	intweet *scorri2;

	if(hash==NULL) printf("\nl'hashtag immesso non è una parola presente in nessun tweet\n");
	else if (!(hash->tag)) printf("\nla parola immessa non è un'hashtag, ma è presente in qualche tweet. Per cercarla, tornare al menù principale, e selezionare la ricerca per parole\n");
	else{
		scorri2=hash->occorrenze;

		while(scorri1!=NULL && scorri2!=NULL){

			if(scorri1->inizio==scorri2->inizio)
			{
				rip++;
				printf("Autore: ");
				stampa_autore(inizio_tweet[scorri1->inizio].autore);
				putchar('\n');
				stampa_testo(scorri1->inizio);
				printf("\n");
			}
			if(scorri1->inizio>scorri2->inizio)
				scorri1=scorri1->next;
			else
				scorri2=scorri2->next;
		}
		if(!rip) printf("\nnon ci sono tweet diretti a questo destinatario che abbiano questo hashtag\n");
	}

}

void stampa_tweet_autoredestinatario(author *origine,author *destinatario){

	int rip=0;
	intweet *scorri1=origine->scrittore;
	intweet *scorri2;

	if(destinatario==NULL) printf("\nil destinatario immesso non corrisponde a nessun utente disponibile\n");
	else{
		scorri2=destinatario->destinatari;

		while(scorri1!=NULL && scorri2!=NULL){

			if(scorri1->inizio==scorri2->inizio)
			{
				rip++;
				stampa_testo(scorri1->inizio);
				printf("\n");
			}
			if(scorri1->inizio>scorri2->inizio)
				scorri1=scorri1->next;
			else
				scorri2=scorri2->next;
		}
		if(!rip) printf("\nL'autore selezionato non ha mai scritto niente al destinatario selezionato\n");
	}
}

void stampa_hashtag(){

	int i;
	for(i=0;i<c;i++){
		printf("#");
		stampa_parola(paroletag[i]);
		printf(" (%d)",paroletag[i]->num_occorrenze);
		printf("\n");
	}
}


/* calcolo del grado di una parola in maniera lineare (o quasi):
 * data una parola, si scorrono le occorrenze, e quindi le parole nei
 * tweet. Per ogni parola, si agisce su tag, aumentandolo di 10, solo
 * se è minore di 2. Ogni volta che si fa questa operazione, si
 * incrementa il contatore del grado. Alla fine bisogna rinormalizzare
 * i tag, con una visita del tray.
 * Infine calcola l'importanza secondo la formula opportuna */
float importanza(carattere *fine){

	fine->tag+=10;
	carattere *vis[110000];
	carattere *aux;
	intweet *scorri;
	parola *scorri2;
	int i=0,twe;
	float imp=0;
	scorri=fine->occorrenze;

	while (scorri!=NULL){

		twe=scorri->inizio;
		scorri2=inizio_tweet[twe].dentro;
		while (scorri2!=NULL){
			if(scorri2->check){
				aux=scorri2->fine;
				if(aux->tag<10){
					aux->tag+=10;
					imp++;
					vis[i]=aux;
					i++;
				}
			}
			scorri2=scorri2->next;
		}
		scorri=scorri->next;
	}

	while(i){
		i--;
		vis[i]->tag-=10;
		if(vis[i]->tag>9 || vis[i]->tag<0) printf("error!!\n");
	}
	fine->tag-=10;
	imp=fine->num_occorrenze/((float)((imp-50)*(imp-50))*0.00006+100);

	return (imp);
}


// cerca la parola nel dizionario, e ne ritorna l'ultimo carattere.
// se non c'è, ritorna NULL, e stampa un messaggio d'errore
carattere *ricercaparola(char* query, int lungh){

	int i;
	int flag=1;
	carattere *cerco;
	cerco=dizionario;
	for(i=0;i<lungh;i++){

		query[i]=lowcase(query[i]);

		if(cerco->figlio==NULL){
			flag=0;
			break;
		}
		else{
			cerco=cerco->figlio;
			while(cerco->lett!=query[i] && cerco->fratello!=NULL)
				cerco=cerco->fratello;
			if(cerco->fratello==NULL && cerco->lett!=query[i])
			{
				flag=0;
				break;
			}
		}
	}

	if (flag)
		if(cerco->num_occorrenze)
			return(cerco);
	return (NULL);
}

// cerca la parola nel dizionario, e ne ritorna l'ultimo carattere.
// se non c'è, ritorna NULL, e stampa un messaggio d'errore
author *ricercaautore(char* query, int lungh){

	int i;
	int flag=1;
	author *cerco;
	cerco=autori;
	for(i=0;i<lungh;i++){

		if(cerco->figlio==NULL){
			flag=0;
			break;
		}
		else{
			cerco=cerco->figlio;
			while(cerco->lett!=query[i] && cerco->fratello!=NULL)
				cerco=cerco->fratello;
			if(cerco->fratello==NULL && cerco->lett!=query[i])
			{
				flag=0;
				break;
			}
		}
	}

	if (flag)
		if(cerco->tweet_scritti || cerco->destinatari!=NULL)
			return(cerco);
	return (NULL);
}


/* crea un carattere di carattere "b" e padre "father"
 * il tag e il num_occorrenze sono 0
 * si vede se è il carattere di fine parola dalle occorrenze */
carattere *creacarattere(char b, carattere *father){

	carattere *a;
	a=(carattere *)malloc(sizeof(carattere));
	a->figlio=NULL;
	a->fratello=NULL;
	a->padre=father;
	a->lett=b;
	a->occorrenze=NULL;
	a->tag=0;
	a->num_occorrenze=0;
	a->importanza=0;


	return (a);
	}

/* crea un autore di lettera "b" e padre "father"
 * il tweet_scritti è 0, e non ha tweet scritti nè è destinatario
 * si vede se è il carattere di fine parola dai tweet scritti */
author *creaautore(char b, author *father){

	author *a;
	a=(author *)malloc(sizeof(author));
	a->figlio=NULL;
	a->fratello=NULL;
	a->padre=father;
	a->lett=b;
	a->destinatari=NULL;
	a->scrittore=NULL;
	a->tweet_scritti=0;
	a->tweet_ricevuti=0;

	return (a);
	}

// crea un intweet da mettere alla fine della parola nel tray
intweet *creaintweet(int inizio){
	intweet *a;
	a=(intweet *)malloc(sizeof(intweet));
	a->next=NULL;
	a->inizio=inizio;
	return (a);
}


/* mette le parole nel tray.
 * viene richiamata passandogli a[] che ha un numero variabile di
 * caratteri, e gli dice dove inizia e finisce la parola
 * inoltre aggiorna il tag e le occorrenze della parola.
 * quindi mette il link all'ultimo carattere nella lista giusta
 * che parte da una cella di inizio_tweet */
void parolaintray(char *a,int in,int fi, int tag,int twe){

	int i,flag=0;
	carattere *cerco;
	carattere *father;
	intweet *scorri;
	intweet *aux;
	cerco=dizionario;
	father=cerco;
	for(i=in;i<=fi;i++){

		a[i]=lowcase(a[i]);
		if(cerco->figlio==NULL){
			cerco->figlio=creacarattere(a[i],father);
			cerco=cerco->figlio;
		}
		else{
			cerco=cerco->figlio;
			while(cerco->lett!=a[i] && cerco->fratello!=NULL)
				cerco=cerco->fratello;
			if(cerco->fratello==NULL && cerco->lett!=a[i])
			{
				cerco->fratello=creacarattere(a[i],father);
				cerco=cerco->fratello;
				}
			}
		father=cerco;
	}

	if (cerco->tag<tag)
		cerco->tag=tag;

	// da notare che la lista occorrenze è ordinata in modo decrescente
	scorri=cerco->occorrenze;
	if(scorri==NULL || scorri->inizio!=twe){

		flag=1;
		aux=creaintweet(twe);
		aux->next=scorri;
		cerco->occorrenze=aux;
		cerco->num_occorrenze++;
	}

	// mette la parola in inizio_tweet[twe], all'inizio della lista, solo se non c'era già
	parola *aux2;

	if(flag){
		aux2=inizio_tweet[twe].dentro;
		inizio_tweet[twe].dentro=(parola *)malloc(sizeof(parola));
		inizio_tweet[twe].dentro->fine=cerco;
		inizio_tweet[twe].dentro->next=aux2;
		inizio_tweet[twe].dentro->check=1;
	}
}

/* preso un autore(check=0) o un destinatario (check=1), lo mette
 * nel tray di autori/destinatari, e aggiorna inizio_tweet con le
 * nuove informazioni */
void autoreintray(char *a,int in,int fi,int check,int twe){


	int i,flag=0;
	author *cerco;
	author *father;
	intweet *scorri;
	intweet *aux;
	cerco=autori;
	father=cerco;
	for(i=in;i<=fi;i++){

		if(cerco->figlio==NULL){
			cerco->figlio=creaautore(a[i],father);
			cerco=cerco->figlio;
		}
		else{
			cerco=cerco->figlio;
			while(cerco->lett!=a[i] && cerco->fratello!=NULL)
				cerco=cerco->fratello;
			if(cerco->fratello==NULL && cerco->lett!=a[i])
			{
				cerco->fratello=creaautore(a[i],father);
				cerco=cerco->fratello;
				}
			}
		father=cerco;
	}

	// da notare che la lista scrittore/destinatario è ordinata in modo decrescente
	address *aux2;

	if(!check) //se è l'autore
	{

		scorri=cerco->scrittore;
		if(scorri==NULL || scorri->inizio!=twe){

			flag=1;
			aux=creaintweet(twe);
			aux->next=scorri;
			cerco->scrittore=aux;
			cerco->tweet_scritti++;
		}

	// mette la parola in inizio_tweet[twe], all'inizio della lista, solo se non c'era già

		if(flag) inizio_tweet[twe].autore=cerco;
	}

	if(check==1) // se è destinatario
	{
		scorri=cerco->destinatari;
		if(scorri==NULL || scorri->inizio!=twe){

			flag=1;
			aux=creaintweet(twe);
			aux->next=scorri;
			cerco->destinatari=aux;
			cerco->tweet_ricevuti++;
		}

		// mette la parola in inizio_tweet[twe], all'inizio della lista, solo se non c'era già

		if(flag){
			aux2=inizio_tweet[twe].destinatari;
			inizio_tweet[twe].destinatari=(address *)malloc(sizeof(address));
			inizio_tweet[twe].destinatari->fine=cerco;
			inizio_tweet[twe].destinatari->next=aux2;
		}

	}
}

//cancella una parola dal tray
void parolafuoritray(char *a,int in,int fi){

	int twe;
	int i, lun;
	char *query;
	parola *scorri;
	intweet *occ;
	lun=fi-in+1;
	query=(char *)malloc((lun+1)*sizeof(char));
	for(i=0;i<lun;i++)
		query[i]=a[in+i];
	query[lun]='\0';

	carattere *par;
	par=ricercaparola(query, lun);

	if(par!=NULL){
		occ=par->occorrenze;
		while(occ!=NULL){
			twe=occ->inizio;
			scorri=inizio_tweet[twe].dentro;
			while(scorri!=NULL){
				if(scorri->fine==par)
					scorri->check=0;
				scorri=scorri->next;
			}
			occ=occ->next;
		}
		par->num_occorrenze=0;
		par->occorrenze=NULL;
		par->tag=0;

	}
}

//mette le parole nella coda di priorità (di 6 elementi)
void linkincoda(carattere *par,link *simili,float peso){

	int i, flag=0;
	link aux, sospeso;
	sospeso.peso=peso;
	sospeso.fine=par;

	for (i=0;i<5;i++){

		if(simili[i].fine==NULL){
			simili[i].peso=sospeso.peso;
			simili[i].fine=sospeso.fine;
			break;
		}
		if(simili[i].fine==par){
			if(simili[i].peso>peso)
				simili[i].peso=peso;
			break;
		}
		if(simili[i].peso>peso){
			flag=1;
			break;
		}
	}

	while(flag){

		aux.peso=simili[i].peso;
		simili[i].peso=sospeso.peso;
		sospeso.peso=aux.peso;

		aux.fine=simili[i].fine;
		simili[i].fine=sospeso.fine;
		sospeso.fine=aux.fine;

		i++;

		if(i==6 || sospeso.fine==par) flag=0;
	}
}


/* preso a[] di 3000 caratteri, con i valori di fine
 * del testo del tweet in a (l'inizio è sempre 24), e il numero del
 * tweet nell'intero documento, riconosce le parole e ci toglie la
 * punteggiatura, e la passa a parolaintray
 * in un vettore, insieme alla sua lunghezza.
 * Seleziona solo le parole con una lunghezza almeno di 3
 * (a[fi] corrisponde a '"' alla fine del testo)  */
void analizza_testo(char *a,int fi, int twe){

	int i=24, j, k;
	int par,lunfalse=0,lun;
	char *b;

	// identifica le parole, scartando i numeri, con unico simbolo "-" in mezzo
	while(i<fi){
		while(i<fi && a[i]!=-61 &&(a[i]<65 || (a[i]>90 && a[i]<97) || (a[i]>122 && a[i]<128) || (a[i]>154 && a[i]<159) || (a[i]>167 && a[i]<181) || (a[i]>183 && a[i]<198) || (a[i]>199 && a[i]<209)  || (a[i]>216 && a[i]<224) || a[i]>237))
		{

			//salta i caratteri speciali
			if(a[i]=='\\') i++;
			i++;
		} //scorre le lettere brutte, tra cui anche "-"
		if (i>=fi) break;
		par=i;
		// controllo per lettere accentate: lunfalse è il numero di lettere accentate e di "-"
		// controlla anche i trattini: se c'è "--" blocca.
		while(i<fi &&  !((a[i]!=45 && a[i]!=-61 && a[i]<65) || (a[i]>90 && a[i]<97) || (a[i]>122 && a[i]<128) || (a[i]>154 && a[i]<159) || (a[i]>167 && a[i]<181) || (a[i]>183 && a[i]<198) || (a[i]>199 && a[i]<209)  || (a[i]>216 && a[i]<224) || a[i]>237)){
			if(a[i]==45 && a[i+1]==45) break;
			if(a[i]==45) lunfalse++;
			if(a[i]==-61 && (a[i+1]==-84 || a[i+1]==-87 || a[i+1]==-71 || a[i+1]==-96 || a[i+1]==-78 || a[i+1]==-88))
				{i++;lunfalse++;}
			else if(a[i]==-61 && !(a[i+1]==-84 || a[i+1]==-87 || a[i+1]==-71 ||
			a[i+1]==-96 || a[i+1]==-78 || a[i+1]==-88))
				break;
			i++;
		}
		// i deve finire in un carattere "cattivo"
		lun=i-par-lunfalse;
		k=i-1;

		// evita tutti i link
		if(a[par]=='h' && a[par+1]=='t' && a[par+2]=='t' && a[par+3]=='p' && a[par+6]=='/'){
			lun=1;
			i+=16;
		}


		// serve per togliere i caratteri "-" da fine parola (45 è l'ASCII per il trattino)
		while(lun>2 && a[k]==45){
			k--;
			lun--;
		}


		if(lun>2) //lunghezza minima parole: 3 caratteri
		{
			lun+=lunfalse;
			b=(char *)malloc((lun)*sizeof(char));
			for(j=par;j<(par+lun);j++)
				b[j-par]=lowcase(a[j]);

			parolaintray(b,0,lun-1,0,twe);

		}
		if(a[i]=='\\') i++;
		i++;
		lunfalse=0;
	}
}

// se messo all'inizio di un numero, ritorna il numero stesso
int numerifica(char *a, int in){

	int sol=0,i=0,j,pot=1;
	while(a[in]!=']' && a[in]!=',')
		{i++;in++;}
	in--;
	for(j=0;j<i;j++){
		sol+=pot*(a[in]-48);
		in--;
		pot*=10;
	}

	return sol;
	}

/* la funzione prende un vettore di 3000 caratteri in cui
 * il testo importante è delimitato da parentesi graffe.
 * ha il compito di riconoscere i campi del tweet, e passare
 * alle funzioni giuste il testo del tweet, gli hashtag e
 * altro. Ai campi giusti, da anche l'informazione "s" che dice qual'è
 * il numero del tweet che si sta analizzando  */
void analizza(char *a, int s){

	int i=24,j,fi;
	int pip,po;

	while(a[i]!=a[23]){
		if(a[i]=='\\') i++;
		i++;
	}
	//scorre il testo, ignorando i caratteri speciali,
	// contraddistinti dal simbolo '\'
	fi=i;

	i+=20; //carattere ' o " del nome
	j=i;
	i++;
	//ci importa poco del nome, quindi lo saltiamo
	while(a[i]!=a[j]){
		if(a[i]=='\\') i++;
		i++;
	}

	i+=19; //primo carattere dello screen_name
	j=i;
	// Lo screen_name non ha caratteri speciali, ed è compreso solo tra apici
	while(a[i]!='\'')
		i++;


	autoreintray(a,j,i-1,0,s);
	// i è l'ultimo carattere, 0 indica l'autore, mentre 1 indica denstinatario

	i+=50;
	// è il carattere dopo '[' di user_mention


	while(a[i]=='{'){

		i+=13;

		//pip e po saranno inizio e fine del destinatario nel testo
		pip=numerifica(a,i);
		while(a[i]!=' ')
			i++;
		i++;
		po=numerifica(a,i);

		pip+=24; po+=24;

		//cancella la parola dal testo del tweet
		for(j=pip;j<po;j++)
			a[j]=' ';

		while(a[i]!=']')
			i++;

		i+=11;
		j=i;
		i++;
		while(a[i]!=a[j]){ //salta il nome
			if(a[i]=='\\') i++;
			i++;
		}

		i+=19;
		j=i;
		while(a[i]!='\'')
			i++;

		autoreintray(a,j,i-1,1,s);
		i+=4;
	}

	analizza_testo(a,fi,s);

	while(a[i]!='\'')
			i++;
	//così arriviamo al primo apice di 'hashtag'

	i+=13;

	while(a[i]=='{'){

		i+=12;
		while(a[i]!=']')
			i++;
		i+=12;
		j=i-1;

		while(a[i]!=a[j]){
			if(a[i]=='\\') i++;
			a[i]=lowcase(a[i]);
			i++;
		}

		parolaintray(a,j+1,i-1,1,s);
		//mette la parola nel tray, segnandolo come hashtag
		i+=4;
	}
}

//2470 è la max lunghezza di un tweet
/* legge tutto il documento e lo divide in tweet.
 * Passa quindi alla funzione "analizza"
 * un vettore di 3000 caratteri, dove il tweet sta tra
 * parentesi graffe; inoltre passa anche un numero che
 * indica il numero del tweet nel documento */
void leggi(){

	printf("lettura documento in corso\n");

	char a[3000];
	char l;
	int i=0, cont=0, iniz, s=0;
	l=text[cont];
	// l è posizionato sempre su '{', oppure
	// se siamo alla fine, su  '\0'
	while(l=='{'){
		s++; //conta il numero del tweet
		i=0;
		iniz=cont; //memorizza il numero del carattere '{'

		while(l!='\n'){
			a[i]=l;
			cont++;
			l=text[cont];
			i++; //tra l'altro, conta la lunghezza del tweet, da { a }
		}

		analizza(a,s);
		inizio_tweet[s].iniz=iniz+24; //primo carattere del testo

		cont++;
		l=text[cont];
		if(s%20000==0) {
			printf("siamo al %d%%",s/1000);
			putchar('\n');
		}
    }

}

//prepara le variabili globali dizionario, inizio_tweet e parole
void inizializza(){

	printf("inizializzazione strutture\n");

	int i;
	for (i=0;i<=100000;i++){
		inizio_tweet[i].dentro=NULL;
		inizio_tweet[i].tag=0;
	}
	for (i=0;i<=150000;i++)
		paroletag[i]=NULL;
	dizionario=creacarattere('\0',NULL);
	autori=creaautore('\0',NULL);
}

//ritorna gli archi tra due parole
int comune(carattere *par1, carattere *par2){

	int rip=0;
	intweet *scorri1=par1->occorrenze;
	intweet *scorri2=par2->occorrenze;

	while(scorri1!=NULL && scorri2!=NULL){

		if(scorri1->inizio==scorri2->inizio)
			rip++;
		if(scorri1->inizio>scorri2->inizio)
			scorri1=scorri1->next;
		else
			scorri2=scorri2->next;
	}

	return (rip);
}

/* cerchiamo le prime 5 parole "simili" alla query, utilizzando il
 * metodo dell'importanza e del peso degli archi, ossia un
 * djkavestra con il peso pari a (rip+50)*(rip2+50)/(archi)^2 */
void parole_simili(carattere* query){

	carattere *origin;
	carattere *vis[110000];
	carattere *aux;
	carattere *primo;
	int i,twe,j=0;
	float archi,rip,rip2,peso;
	parola *scorri2;
	link simili[6];
	for(i=0;i<6;i++) simili[i].fine=NULL;
	origin=query;
	primo=origin;
	intweet *scorri;
	if(origin!=NULL){
		rip=origin->num_occorrenze;
		scorri=origin->occorrenze;
	}
	//printf("ricerca in corso\n");
	// analizza le parole adiacenti ad origin

	rip=origin->num_occorrenze;
	scorri=origin->occorrenze;
	while (scorri!=NULL){
		twe=scorri->inizio;
		scorri2=inizio_tweet[twe].dentro;
		while (scorri2!=NULL){
			if(scorri2->check){
				aux=scorri2->fine;
				if(aux->tag<9 && aux!=origin && aux!=primo){
					rip2=aux->num_occorrenze;
					archi=comune(aux,origin);
					peso=(rip+50)*(rip2+50);
					peso/=(archi*archi*100);
					//peso*=peso;
					peso/=(aux->importanza);
					peso/=(aux->importanza);
					//if(aux->importanza<1)
					//peso/=(aux->importanza);
					linkincoda(aux,simili,peso);
					aux->tag+=10;
					vis[j]=aux;
					j++;
				}
			}
			scorri2=scorri2->next;
		}
		scorri=scorri->next;
	}
	while(j){
		j--;
		vis[j]->tag-=10;
		if(vis[j]->tag>9 || vis[j]->tag<0) printf("error!!\n");
	}


	printf("le 5 parole più simili a ");
	stampa_parola(query);
	printf(" sono:\n");
	for(i=0;i<5;i++) {
		stampa_parola(simili[i].fine);
		printf("\n");
	}

}

//da richiamare con dizionario, mette l'importanza nelle parole,
//e crea l'array di parole
void prepara_percentuali(carattere *a){


	carattere *scorri1=a;

	if(scorri1->occorrenze!=NULL){
		scorri1->importanza=importanza(scorri1);
		if(scorri1->tag) {
			paroletag[c]=scorri1;
			c++;
		}
	}
	scorri1=scorri1->figlio;
	while(scorri1!=NULL){
		prepara_percentuali(scorri1);
		scorri1=scorri1->fratello;
	}

}

// max 30 parole in un tweet. 30*5=150
void tagga_tweet(){


	printf("tag dei tweet senza hashtag in corso..\n");
	link simili[200];
	carattere *domina=NULL;
	float min=100000;
	parola* scorri;
	int cont=0,j,i;


	for(i=1;i<=100000;i++){
		if(!inizio_tweet[i].tag){
			scorri=inizio_tweet[i].dentro;
			while(scorri!=NULL){
				if(scorri->check){
					simili[cont].fine=scorri->fine;
					simili[cont].peso=1/scorri->fine->importanza;
					cont++;
				}
				scorri=scorri->next;
			}
			if(cont){
				for(j=0;j<cont;j++){
					if(simili[j].peso<min) {
						min=simili[j].peso;
						domina=simili[j].fine;
					}
				}

				if(!domina->tag){
					domina->tag=1;
					paroletag[c]=domina;
					c++;
				}

				inizio_tweet[i].tag=1;
			}
		}

		cont=0;
		min=100000;

	}
}

void prepara_tag(){

	printf("taggatura dei tweet primaria in corso..\n");

	int i;
	parola *scorri;
	int flag=0;

	for(i=1;i<=100000;i++){

		scorri=inizio_tweet[i].dentro;
		while(scorri!=NULL){
			if(scorri->check && scorri->fine->tag){
				inizio_tweet[i].tag=1;
				flag=1;
				break;
			}
			scorri=scorri->next;
		}
		if(!flag)
			inizio_tweet[i].tag=0;
		flag=0;
	}
}

void elimina_preposizioni(){

	printf("eliminazione preposizioni in corso..\n");

	char a1[]="di";
	parolafuoritray(a1,0,1);

	char a2[]="del";
	parolafuoritray(a2,0,2);

	char a3[]="della";
	parolafuoritray(a3,0,4);

	char a4[]="dello";
	parolafuoritray(a4,0,4);

	char a5[]="degli";
	parolafuoritray(a5,0,4);

	char a6[]="delle";
	parolafuoritray(a6,0,4);

	char a7[]="dell";
	parolafuoritray(a7,0,3);

	char a8[]="a";
	parolafuoritray(a8,0,0);

	char a9[]="al";
	parolafuoritray(a9,0,1);

	char a10[]="alla";
	parolafuoritray(a10,0,3);

	char a11[]="allo";
	parolafuoritray(a11,0,3);

	char a12[]="agli";
	parolafuoritray(a12,0,3);

	char a13[]="alle";
	parolafuoritray(a13,0,3);

	char a14[]="da";
	parolafuoritray(a14,0,1);

	char a15[]="dal";
	parolafuoritray(a15,0,2);

	char a16[]="dallo";
	parolafuoritray(a16,0,4);

	char a17[]="dagli";
	parolafuoritray(a17,0,4);

	char a18[]="dalle";
	parolafuoritray(a18,0,4);

	char a19[]="dall";
	parolafuoritray(a19,0,3);

	char a20[]="in";
	parolafuoritray(a20,0,1);

	char a21[]="nel";
	parolafuoritray(a21,0,2);

	char a22[]="nella";
	parolafuoritray(a22,0,4);

	char a23[]="nello";
	parolafuoritray(a23,0,4);

	char a24[]="negli";
	parolafuoritray(a24,0,4);

	char a25[]="nelle";
	parolafuoritray(a25,0,4);

	char a26[]="nell";
	parolafuoritray(a26,0,3);

    char a27[]="con";
	parolafuoritray(a27,0,2);

	char a28[]="col";
	parolafuoritray(a28,0,2);

	char a29[]="su";
	parolafuoritray(a29,0,1);

	char a30[]="sul";
	parolafuoritray(a30,0,2);

	char a31[]="sulla";
	parolafuoritray(a31,0,4);

	char a32[]="sullo";
	parolafuoritray(a32,0,4);

	char a33[]="sugli";
	parolafuoritray(a33,0,4);

	char a34[]="sulle";
	parolafuoritray(a34,0,4);

	char a35[]="sull";
	parolafuoritray(a35,0,3);

	char a36[]="per";
	parolafuoritray(a36,0,2);

	char a37[]="tra";
	parolafuoritray(a37,0,2);

	char a38[]="fra";
	parolafuoritray(a38,0,2);


	char a39[]="gli";
	parolafuoritray(a39,0,2);

	char a40[]="il";
	parolafuoritray(a40,0,1);

	char a41[]="la";
	parolafuoritray(a41,0,1);

	char a42[]="l";
	parolafuoritray(a42,0,0);

	char a43[]="le";
	parolafuoritray(a43,0,1);

	char a44[]="lo";
	parolafuoritray(a44,0,1);

	char a45[]="i";
	parolafuoritray(a45,0,0);

	char a46[]="dai";
	parolafuoritray(a46,0,2);

	char a47[]="coi";
	parolafuoritray(a47,0,2);

	char a48[]="sui";
	parolafuoritray(a48,0,2);

	char a49[]="non";
	parolafuoritray(a49,0,2);

	char a50[]="uno";
	parolafuoritray(a50,0,2);

	char a51[]="una";
	parolafuoritray(a51,0,2);

	char a52[]="un";
	parolafuoritray(a52,0,1);

	char a53[]="che";
	parolafuoritray(a53,0,2);

	char a54[]="seguo";
	parolafuoritray(a54,0,4);

	char a55[]="seguimi";
	parolafuoritray(a55,0,6);

	char a56[]="rt";
	parolafuoritray(a56,0,1);

	char a57[]="sono";
	parolafuoritray(a57,0,3);

	char a58[]="tuo";
	parolafuoritray(a58,0,2);

	char a59[]="hai";
	parolafuoritray(a59,0,2);

	char a60[5];
	a60[0]='p';
	a60[1]='i';
	a60[2]=-61;
	a60[3]=-71;
	a60[4]='\0';
	parolafuoritray(a60,0,3);

	char a61[]="all";
	parolafuoritray(a61,0,2);

	char a62[]="come";
	parolafuoritray(a62,0,3);

	char a63[]="sempre";
	parolafuoritray(a63,0,5);

	char a64[]="tutti";
	parolafuoritray(a64,0,4);

	char a65[]="tutto";
	parolafuoritray(a65,0,4);

	char a66[]="mia";
	parolafuoritray(a66,0,2);

	char a67[]="mio";
	parolafuoritray(a67,0,2);

	char a68[]="voglio";
	parolafuoritray(a68,0,5);

	char a69[]="cosa";
	parolafuoritray(a69,0,3);

	char a70[6];
	a70[0]='c';
	a70[1]='o';
	a70[2]='s';
	a70[3]=-61;
	a70[4]=-84;
	a70[5]='\0';
	parolafuoritray(a70,0,4);

	char a71[]="chi";
	parolafuoritray(a71,0,2);

	char a72[]="fare";
	parolafuoritray(a72,0,3);

	char a73[]="essere";
	parolafuoritray(a73,0,5);

	char a74[]="quando";
	parolafuoritray(a74,0,5);

	char a75[]="questa";
	parolafuoritray(a75,0,5);

	char a76[]="ora";
	parolafuoritray(a76,0,2);

	char a77[]="anch";
	parolafuoritray(a77,0,3);

	char a78[]="anche";
	parolafuoritray(a78,0,4);

	char a79[]="ero";
	parolafuoritray(a79,0,2);

	char a80[]="lei";
	parolafuoritray(a80,0,2);

	char a81[]="devo";
	parolafuoritray(a81,0,3);

	char a82[]="siano";
	parolafuoritray(a82,0,4);

	char a83[]="sto";
	parolafuoritray(a83,0,2);

	char a84[]="voi";
	parolafuoritray(a84,0,2);

	char a85[]="stai";
	parolafuoritray(a85,0,3);

}



int main()
{

	int n,lun=1,lun2=1,i,ric=1,ric2=1,trash;
	inizializza();
	char a[140];
	char b[140];
	
	fp=fopen("dati_definitivi.txt","r");


	struct stat stat_buf;
	fstat(fileno(fp),&stat_buf);
	n=stat_buf.st_size;

	text=(char *)mmap(NULL, n, PROT_READ, MAP_SHARED, fileno(fp), 0);


	leggi (); //legge e crea il dizionario
	elimina_preposizioni(); //elimina parole poco importanti
	printf("attribuzione importanza alle parole in corso..\n");
	prepara_percentuali(dizionario); //prepara le statistiche sulle singole parole
	prepara_tag(); //tagga i tweet in maniera banale
	tagga_tweet(); //tagga i tweet ancora non taggati
	elimina_preposizioni(); //elimina nuovamente le parole poco importanti
	prepara_tag(); //regolarizza infine tutti i tag


	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n");

	for(i=0;i<43;i++) printf("*");
	printf("\n* benvenuti al motore di ricerca by Exodd *\n");
	for(i=0;i<43;i++) printf("*");

	printf("\n\n\n");

	author *cerco;
	author *cerco2;
	carattere *cerca;

	while(ric){

		ric2=1;
		printf("\n\nIstruzioni:\nCon questo programma potrete cercare i tweet partendo dall'autore, dai destinatari, dagli hashtag, o semplicemente dalle parole contenute in essi.\nPer continuare, digitare:\n0 - Uscita\n1 - Ricerca tramite Autore\n2 - Ricerca tramite Destinatario\n3 - Ricerca tramite Hashtag\n4 - Ricerca tramite Parola\n\nChe ricerca vuoi effettuare? (0/1/2/3/4): ");

		trash=scanf("%d",&ric);
		printf("\n");

		while(ric && ric<5 && ric>-1){
			if(ric==1){
				if(ric2){
					printf("\n\nPer avere una lista completa degli autori, digitare 1\nPer tornare al Menù principale, digitare 0\nDigita il nome dell'autore o una delle opzioni sopra (WARNING: è case sensitive): ");
					trash=scanf("%s",a);
					printf("\n");
					for(lun=0;a[lun]!='\0';lun++);
				}
				if(lun==1){
					if(a[0]=='1')
						stampa_autori(autori);
					else
						ric=5;
				}
				else{
					cerco=ricercaautore(a,lun);
					if(cerco==NULL || cerco->tweet_scritti==0) {

						printf("\n\nQuesto autore non esiste o non ha scritto alcun tweet\n\nPer provare di nuovo, digitare 1, per ritornare al menù principale, digitare 0: ");
						trash=scanf("%d",&ric);
						printf("\n");
						if(!ric) ric=5;
					}
					else {

						printf("\n\nQuesto autore ha scritto %d tweet.\n\n0 - Ritorna al menù principale\n1 - Visualizza i tweet\n2 - Filtra i tweet secondo Hashtag\n3 - Filtra i tweet secondo Destinatari\n4 - Provare un altro autore\nDigitare la scelta (0/1/2/3/4): ",cerco->tweet_scritti);

						trash=scanf("%d",&ric2);
						printf("\n");
						while(ric2>4 || ric2<0){
							printf("\nnumero invalido! Per favore, immetterne uno valido: ");
							trash=scanf("%d",&ric2);
							printf("\n");
						}
						if(!ric2) ric=5;
						if(ric2==1){
							stampa_tweet_autore(cerco);
							ric2=0;
						}
						if(ric2==2){
							printf("\ngli hashtag presenti nei tweet di %s sono:\n", a);
							stampa_hash_autore(cerco);
							while(ric2==2){
								printf("\nPer tornare alla scelta autore, digitare 1\nPer tornare al menù principale, digitare 0\nDigitare l'hashtag per cui si desidera filtrare: ");
								trash=scanf("%s",b);
								printf("\n");
								for(lun2=0;b[lun2]!='\0';lun2++);
								if(lun2==1){
									if(b[0]=='0')
										ric=5;
									else
										ric=1;

									ric2=1;
								}
								else{
									cerca=ricercaparola(b,lun2);
									if(cerca!=NULL)
										stampa_tweet_autorehash(cerco,cerca);
								}
							}
						}
						if(ric2==3){
							printf("\ni destinatari presenti nei tweet di %s sono:\n", a);
							stampa_destinatari_autore(cerco);
							while(ric2==3){
								printf("\nPer tornare alla scelta autore, digitare 1\nPer tornare al menù principale, digitare 0\nDigitare il destinatario per cui si desidera filtrare: ");
								for(i=0;i<140;i++) b[i]='\0';
								trash=scanf("%s",b);
								printf("\n");
								for(lun2=0;b[lun2]!='\0';lun2++);
								if(lun2==1){
									if(b[0]=='0')
										ric=5;
									else
										ric=1;

									ric2=1;
								}
								else{
									cerco2=ricercaautore(b,lun2);
									if(cerco2!=NULL)
										stampa_tweet_autoredestinatario(cerco,cerco2);
								}
							}

						}
					}
				}
			}
			if(ric==2){
				if(ric2){
					printf("\n\nPer avere una lista completa dei destinatari, digitare 1\nPer tornare al Menù principale, digitare 0\nDigita il nome del destinatario, o una delle opzioni sopra (WARNING: è case sensitive): ");
					trash=scanf("%s",a);
					printf("\n");
					for(lun=0;a[lun]!='\0';lun++);
				}
				if(lun==1){
					if(a[0]=='1')
						stampa_destinatari(autori);
					else if(a[0]=='0')
						ric=5;
					else
						printf("\nnon esistono destinatari di 1 lettera\n");
				}
				else{
					cerco=ricercaautore(a,lun);
					if(cerco==NULL || cerco->destinatari==NULL) {

						printf("\n\nQuesto utente non esiste o non ha mai ricevuto tweet\n\nPer provare di nuovo, digitare 2, per ritornare al menù principale, digitare 0: ");
						trash=scanf("%d",&ric);
						printf("\n");
						if(!ric) ric=5;
					}
					else {

						printf("\n\nQuesto autore ha ricevuto %d tweet.\n\n0 - Ritorna al menù principale\n1 - Visualizza i tweet\n2 - Filtra i tweet secondo Hashtag\n3 - Filtra i tweet secondo Autore\n4 - Provare un altro destinatario\nDigitare la scelta (0/1/2/3/4): ",cerco->tweet_ricevuti);

						trash=scanf("%d",&ric2);
						printf("\n");
						while(ric2>4 || ric2<0){
							printf("\nnumero invalido! Per favore, immetterne uno valido: ");
							trash=scanf("%d",&ric2);
							printf("\n");
						}

						if(!ric2) ric=5;
						if(ric2==1){
							stampa_tweet_destinatario(cerco);
							ric2=0;
						}
						if(ric2==2){
							printf("\ngli hashtag presenti nei tweet ricevuti da %s sono:\n", a);
							stampa_hash_destinatario(cerco);
							while(ric2==2){
								printf("\nPer tornare alla scelta del destinatario, digitare 2\nPer tornare al menù principale, digitare 0\nDigitare l'hashtag per cui si desidera filtrare: ");
								trash=scanf("%s",b);
								printf("\n");
								for(lun2=0;b[lun2]!='\0';lun2++);
								if(lun2==1){
									if(b[0]=='0')
										ric=5;
									else
										ric=2;

									ric2=1;
								}
								else{
									cerca=ricercaparola(b,lun2);
									if(cerca!=NULL)
										stampa_tweet_destinatariohash(cerco,cerca);
								}
							}
						}
						if(ric2==3){
							printf("\ngli autori che hanno scritto tweet a %s sono:\n", a);
							stampa_autori_destinatario(cerco);
							while(ric2==3){
								printf("\nPer tornare alla scelta del destinatario, digitare 2\nPer tornare al menù principale, digitare 0\nDigitare l'autore per cui si desidera filtrare: ");
								for(i=0;i<140;i++) b[i]='\0';
								trash=scanf("%s",b);
								printf("\n");
								for(lun2=0;b[lun2]!='\0';lun2++);
								if(lun2==1){
									if(b[0]=='0')
										ric=5;
									else
										ric=2;

									ric2=1;
								}
								else{
									cerco2=ricercaautore(b,lun2);
									if(cerco2!=NULL)
										stampa_tweet_autoredestinatario(cerco2,cerco);
								}
							}

						}
					}
				}
			}
			if(ric==3){

				if(ric2){
					printf("\n\nPer avere una lista completa degli hashtag, digitare 1\nPer tornare al Menù principale, digitare 0\nDigita l'hashtag, o una delle opzioni sopra: ");
					trash=scanf("%s",a);
					printf("\n");
					for(lun=0;a[lun]!='\0';lun++);
				}
				if(lun==1){
					if(a[0]=='1')
						stampa_hashtag();
					else if(a[0]=='0')
						ric=5;
					else
						printf("\nnon esistono hashtag sensati di 1 lettera\n");
				}
				else{
					cerca=ricercaparola(a,lun);
					if(cerca==NULL){
						printf("\n\nQuesta parola non è presente in nessun tweet\n\nPer provare di nuovo, digitare 3, per ritornare al menù principale, digitare 0: ");
						trash=scanf("%d",&ric);
						printf("\n");
						if(!ric) ric=5;
					}
					else if(cerca->tag==0) {

						printf("\n\nQuesta parola esiste, ma non è un hashtag. Per cercarla, tornare al menù principale, e selezionare ricerca parole\n\nPer provare di nuovo, digitare 3, per ritornare al menù principale, digitare 0: ");
						trash=scanf("%d",&ric);
						printf("\n");
						if(!ric) ric=5;
					}
					else {

						printf("\n\nQuesto hashtag è presente in %d tweet.\n\n0 - Ritorna al menù principale\n1 - Visualizza i tweet\n2 - Filtra i tweet secondo Destinatario\n3 - Filtra i tweet secondo Autore\n4 - Provare un altro hashtag\n5 - visualizzare parole simili\nDigitare la scelta (0/1/2/3/4/5): ",cerca->num_occorrenze);

						trash=scanf("%d",&ric2);
						printf("\n");
						while(ric2>5 || ric2<0){
							printf("\nnumero invalido! Per favore, immetterne uno valido: ");
							trash=scanf("%d",&ric2);
							printf("\n");
						}
						if(!ric2) ric=5;
						if(ric2==1){
							stampa_tweet_parola(cerca);
							ric2=0;
						}
						if(ric2==2){
							printf("\ni tweet con l'hashtag %s sono stati mandati a:\n", a);
							stampa_destinatari_hash(cerca);
							while(ric2==2){
								printf("\nPer tornare alla scelta dell'hashtag, digitare 3\nPer tornare al menù principale, digitare 0\nDigitare il destinatario per cui si desidera filtrare: ");
								trash=scanf("%s",b);
								printf("\n");
								for(lun2=0;b[lun2]!='\0';lun2++);
								if(lun2==1){
									if(b[0]=='0')
										ric=5;
									else
										ric=3;

									ric2=1;
								}
								else{
									cerco=ricercaautore(b,lun2);
									if(cerco!=NULL)
										stampa_tweet_destinatariohash(cerco,cerca);
								}
							}
						}
						if(ric2==3){
							printf("\ngli autori che hanno scritto tweet con %s come hashtag sono:\n", a);
							stampa_autori_hash(cerca);
							while(ric2==3){
								printf("\nPer tornare alla scelta dell'hashtag, digitare 3\nPer tornare al menù principale, digitare 0\nDigitare l'autore per cui si desidera filtrare: ");
								for(i=0;i<140;i++) b[i]='\0';
								trash=scanf("%s",b);
								printf("\n");
								for(lun2=0;b[lun2]!='\0';lun2++);
								if(lun2==1){
									if(b[0]=='0')
										ric=5;
									else
										ric=3;

									ric2=1;
								}
								else{
									cerco2=ricercaautore(b,lun2);
									if(cerco2!=NULL)
										stampa_tweet_autorehash(cerco2,cerca);
								}
							}

						}
						if(ric2==5)
							parole_simili(cerca);
					}
				}


			}
			if(ric==4){
				if(ric2){
					printf("\n\nPer tornare al Menù principale, digitare 0\nDigita la parola, o una delle opzioni sopra: ");
					trash=scanf("%s",a);
					printf("\n");
					for(lun=0;a[lun]!='\0';lun++);
				}
				if(lun==1){
					if(a[0]=='0')
						ric=5;
					else
						printf("\nnon esistono parole sensate di 1 lettera\n");
				}
				else{
					cerca=ricercaparola(a,lun);
					if(cerca==NULL){
						printf("\n\nQuesta parola non è presente in nessun tweet\n\nPer provare di nuovo, digitare 4, per ritornare al menù principale, digitare 0: ");
						trash=scanf("%d",&ric);
						printf("\n");
						if(!ric) ric=5;
					}
					else {
						printf("\n\nQuesta parola è presente in %d tweet.\n\n0 - Ritorna al menù principale\n1 - Visualizza i tweet\n2 - Provare un'altra parola\n3 - visualizzare parole simili\nDigitare la scelta (0/1/2): ",cerca->num_occorrenze);

						trash=scanf("%d",&ric2);
						printf("\n");
						while(ric2>3 || ric2<0){
							printf("\nnumero invalido! Per favore, immetterne uno valido: ");
							trash=scanf("%d",&ric2);
							printf("\n");
						}
						if(!ric2) ric=5;
						if(ric2==1) {
							stampa_tweet_parola(cerca);
							ric2=0;
						}
						if(ric2==3)
							parole_simili(cerca);
					}
				}
			}
		}

	}

	if(!ric) printf("\nGrazie per aver scelto questo programma di ricerca, e arrivederci!\n\n\n\n");

	if(!trash);
	fclose(fp);
	return 0;

}
