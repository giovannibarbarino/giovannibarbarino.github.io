function r=pls(A,y,k)

% A è una matrice m x n, y è un vettore di lunghezza m, con m>=n.
% l'algoritmo ritorna il residuo dato dal PLS dopo s passi, per ogni s da 1 a k, con k<=n

B=A;
n=size(A)(2);

% il vettore dei residui r, parte dalla norma di y

r(1)=norm(y);

for i=1:k

	% un passo del PLS

	w=A'*y;
	w=w/norm(w);
	t=A*w;
	t=t/norm(t);
	p=A'*t;
	A=A-t*p';
	
	% costruzione delle matrici W,T,P
	
	W(:,i)=w;
	T(:,i)=t;
	P(:,i)=p;
	
	% calcolo del residuo
	
	r(i+1)=norm(B*W*(P'*W)^(-1)*T'*y-y);

endfor


endfunction
