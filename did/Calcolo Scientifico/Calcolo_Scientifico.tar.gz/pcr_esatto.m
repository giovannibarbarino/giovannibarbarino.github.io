function res=pcr_esatto(A,y)


% A è una matrice m x n con m>=n, y è un vettore di lunghezza m
% l'algoritmo restituisce il residuo quadro generato dal metodo PCR per ogni k da 1 al rango della matrice
% il residuo non viene calcolato tramite la soluzione al problema, ma tramite la formula res^2 = somma( s^t * y )^2

n=size(A)(2);
[S,D,Q]=svd(A);
d=diag(D);

% calcolo del rango della matrice

i=n;

while( d(i)<10^(-15) && i>0 ) i--;
endwhile 

r=i;


R=(S'*y).^2;
res(1)=sum(R);


% calcolo di soluzione al passo k e residuo

for k=1:r
	res(k+1)=res(k)-R(k);
endfor





endfunction
