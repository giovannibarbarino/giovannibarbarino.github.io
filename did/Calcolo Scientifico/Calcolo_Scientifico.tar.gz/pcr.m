function res=pcr(A,y)


% A è una matrice m x n con m>=n, y è un vettore di lunghezza m
% l'algoritmo restituisce il residuo generato dal metodo PCR per ogni k da 1 al rango della matrice

n=size(A)(2);
[S,D,Q]=svd(A);
d=diag(D);

% calcolo del rango della matrice

i=n;

while( d(i)<10^(-15) && i>0 ) i--;
endwhile 

r=i;

% calcolo dei vettori (s^t * y / sigma) * q

d=d(1:r);
R=diag(((d.^(-1)).*(S'*y)(1:r)));
M=(Q(:,1:r))*R;

x=zeros(n,1);

% calcolo di soluzione al passo k e residuo

for k=1:r
	x+=M(:,k);
	res(k)=norm(A*x-y);
endfor





endfunction
