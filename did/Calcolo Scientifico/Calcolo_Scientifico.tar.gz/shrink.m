function F=shrink(A,y)


% A è una matrice quadrata di rango massimo, e y è un vettore 
% l'algoritmo ritorna i primi 5 fattori di rimpicciolimento dati dall'LPS

% calcolo dei coefficienti ( sigma / s^t * y ) 

[S,D,Q]=svd(A);
R=diag(D*((S'*y).^(-1)));

B=A;


for i=1:5

	% un passo dell'LPS
	
	w=A'*y;
	w=w/norm(w);
	t=A*w;
	t=t/norm(t);
	p=A'*t;
	A=A-t*p';
	
	% costruzione delle matrici W,T,P
	
	W(:,i)=w;
	T(:,i)=t;
	P(:,i)=p;
	
	% calcolo della soluzione di rango k
	
	x=W*(P'*W)^(-1)*T'*y;
	
	% calcolo dei coefficienti del fattore di rimpicciolimento
	
	F(:,i)=R*Q'*x;


endfor


endfunction
