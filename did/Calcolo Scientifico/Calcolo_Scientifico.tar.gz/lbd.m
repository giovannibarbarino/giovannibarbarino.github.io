function r=lbd(A,y,k)

% A è una matrice m x n, y è un vettore di lunghezza m, con m>=n.
% l'algoritmo ritorna il residuo dato dall'LBD dopo s passi, per ogni s da 1 a k, con k<=n

% il vettore dei residui r, parte dalla norma di y

r(1)=norm(y);

% passo iniziale dell'LBD

v=A'*y;
gam=norm(v);
v=v/gam;
u=A*v;
alfa=norm(u);
u=u/alfa;

% costruzione delle matrici V,U,B al primo passo

V(:,1)=v;
U(:,1)=u;
B(1,1)=alfa;

% calcolo della soluzione e del residuo

x=V*B^(-1)*U'*y;
r(2)=norm(A*x-y);


for i=2:k

	% un passo dell'LBD	

	v=A'*u-alfa*v;
	gam=norm(v);
	v=v/gam;
	u=A*v-gam*u;
	alfa=norm(u);
	u=u/alfa;
	
	% costruzione delle matrici V,U,B
	
	V(:,i)=v;
	U(:,i)=u;
	B(i-1,i)=gam;
	B(i,i)=alfa;
	
	% calcolo della soluzione e del residuo
		
	x=V*B^(-1)*U'*y;
	r(i+1)=norm(A*x-y);

endfor

endfunction
