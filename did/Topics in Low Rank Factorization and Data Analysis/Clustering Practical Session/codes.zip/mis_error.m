function m = mis_error(v,w)
% v,w are rows
% v is the true clustering v_i. w is the approximated one w_j
% the misclassification error is
% min_p  max_i  | v_i symdiff w_p(i) | / |v_i|

assert(length(v)==length(w),'le due assegnazioni hanno lunghezza diversa');
q = max(max(v),max(w));
N = length(v);

P = perms(1:q);
NN = size(P,1);
assert( NN == factorial(q), 'wtf??');

% let's check all v_i are not empty...
Nv = zeros(1,q);
for i = 1:q
    Nv(i) = length(v(v==i));
    assert(Nv(i)>0, 'empty ideal clusters???')
end

m = N+1;

for j = 1:NN
    perm = P(j,:);
    aux = 0;

    for i = 1:q
        z = sum(xor(v==i,w==perm(i)))/Nv(i);
        if(z>=m)
            aux = m;
            break;
        end
        aux = max(aux,z);
    end

    m = min(aux,m);
    if (m==0) 
        break; 
    end
end











end