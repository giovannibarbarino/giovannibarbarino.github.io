function [idx, eigL, err] = Spec_Clust(S,k)
% S must be a square similarity matrix, k the
% rank. Returns the indices associated to each
% cluster and the eigenvalues of the laplacian.
% Return also as error the inverse of the spectral gap.
assert(size(S,1) == size(S,2)); 
assert(all(all(S>-.00001)));
n = size(S,1); 
assert(norm(S-S')<.00001*sqrt(n));
S(S<0) = 0; S = (S+S')/2;
d = sum(S); L = diag(d) - S;
% [V, D] = eigs(L,2*k,'smallestreal');
[V, D] = eig(L);

eigL = sort(diag(D)); err = 1/(eigL(k+1) - eigL(k));
idx = kmeans(V(:,1:k),k);

end