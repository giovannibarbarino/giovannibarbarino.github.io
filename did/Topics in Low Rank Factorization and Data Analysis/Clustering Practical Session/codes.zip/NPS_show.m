clf;
hold on;
C = [0 1 0; 0 0 1; 1 0 0];
Ci = ones(3)-C;

cnt = 1; nm = 30;
for p = .7:-.05:.55
    B = p*C + (1-p)*Ci;
    [m,A,idxx] = s1_misclass(nm,B);
    subplot(2,4,2*cnt-1); imagesc(A);
    subplot(2,4,2*cnt); imagesc(idxx);
    ax = gca; ax.Position(3) = ax.Position(3)/3;
    ax.XTick = [];
    m
    cnt = cnt+1;
end

%% several_instances

N = 100;
C = [0 1 0; 0 0 1; 1 0 0];
Ci = ones(3)-C;
m = zeros(1,4); cnt = 1; nm = 30; 
for p = .7:-.05:.55
    B = p*C + (1-p)*Ci;
    for i = 1:N
        m(cnt) = m(cnt) + s1_misclass(nm,B);
    end
    m(cnt) = m(cnt)/N; 
    cnt = cnt+1;
end
m

%% bigger dimension

clf;
N = 100; dimm = 10;
C = [0 1 0; 0 0 1; 1 0 0];
Ci = ones(3)-C; p = .55; 
B = p*C + (1-p)*Ci;
m = zeros(1,dimm); nm = 30; 
for nn = 1:dimm
    for i = 1:N
        m(nn) = m(nn) + s1_misclass(nm*nn,B);
    end
    m(nn) = m(nn)/N; 
end
plot(nm*[1:dimm],m);
