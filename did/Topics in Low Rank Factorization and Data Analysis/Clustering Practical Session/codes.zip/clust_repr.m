function err = clust_repr(km,N)


assoc = zeros(1,20);
for i = 1:20
    aux = km(10*(i-1)+1:10*i);
    [~, ind] = sort(sum(bsxfun(@eq,aux,aux.')));
    aux = aux(ind); aux = aux(end:-1:1);
    flag = 1; cnt = 1;
    while flag
        if assoc(aux(cnt))==0 
            assoc(aux(cnt))=i; flag = 0;
        else
            if cnt == 10
                flag = 0;
            end
            cnt = cnt+1;
        end
    end
end
kmm = assoc(km);
scatter(1:N,kmm,50,'filled');

errv = kmm - kron([1:20],ones(1,10));
err = sum(errv~=0)/N;

end