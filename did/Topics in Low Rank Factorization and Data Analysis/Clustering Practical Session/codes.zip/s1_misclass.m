function [m,A_id,idxx] = s1_misclass(N,B)

% N*size(B,1) is the size of the matrix. 
% B is a full-rank qxq matrix with entries between 0 and 1


q = size(B,1);
NN = N*q;
assert(q==size(B,2),"B not square");
assert(rank(B)==q,"B not full rank");
assert(max(max(B)) <= 1, "B has elements greater than 1")
assert(min(min(B)) >= 0, "B has negative elements")

v = 1:q; v = kron(v,ones(1,N));

    p = randperm(NN);
    A_id = zeros(NN);
    for i=1:q
        for j=1:q
            A_id(1+(i-1)*N:i*N,1+(j-1)*N:j*N) = ...
                bernp(N,B(i,j));
        end
    end
    A = A_id(p,p);
    R = [A A'];
    S = R*R';
    [U,~,~,cflag] = svds(S,q);
    assert(cflag==0,"svd didn't converge");
    idx = kmeans(U,q);

    pt(p) = 1:NN;
    m = mis_error(v(p),idx');    
    idxx = idx(pt);
end
