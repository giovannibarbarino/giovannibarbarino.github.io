% A is 8000x2
clf;
k = 20;
X = preprocessing(50);
[km] = kmeans(X',k);

err = clust_repr(km,size(X,2))


%% Spectral Clustering

clf;
k = 20;
X = preprocessing(50);
X = X*diag(vecnorm(X).^(-1));
S = exp(-.5*pdist2(X',X','fastsquaredeuclidean'));

[idx] = Spec_Clust(S,k);
err = clust_repr(idx,size(X,2))

%% Spectral Clustering with 1-neighbourhood

clf;
k = 20;
X = preprocessing(50);  
X = X*diag(vecnorm(X).^(-1));
Aux = pdist2(X',X','fastsquaredeuclidean');
S = zeros(size(X,2)); S(Aux<=1) = 1;

[idx] = Spec_Clust(S,k);
err = clust_repr(idx,size(X,2))

%% Spectral Clustering with 8-NN

clf;
k = 20; KK = 8;
X = preprocessing(50);  
X = X*diag(vecnorm(X).^(-1));
Aux = pdist2(X',X','fastsquaredeuclidean');
S = zeros(size(X,2));
for i = 1:size(X,2)
    aa = sort(Aux(i,:),'descend'); 
    S(i,Aux(i,:)>=aa(8))= 1;
end
S = (S+S')/2;

[idx] = Spec_Clust(S,k);
err = clust_repr(idx,size(X,2))

