% A is 8000x2

k = 6; c = .001;
A = load('t4.8k.txt'); A = A(2:end,:);

 A = A(1:3:end,:);

S = exp(-c*pdist2(A,A,'fastsquaredeuclidean'));
S(S<.8) = 0; ss = sum(S); ids = (ss>10);
S = S(ids,ids);
A = A(ids,:); 

% sum(ids)

clf;
[idx,ee,~] = Spec_Clust(S,k);
scatter(A(:,1),A(:,2),50,idx,'filled');
ee(1:2*k)

%%

% clf;
% err = [];
% for k = 6:100
%     [~,~,sumd] = kmeans(A,k);
%     err(k-5) = sum(sumd)+2*k*10^5; 
% end
% plot(err);