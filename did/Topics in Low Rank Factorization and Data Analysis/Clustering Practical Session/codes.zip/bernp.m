function M = bernp(n,p)
%BERNP generates nxn Bernoulli(p) matrix

M = rand(n);
M = M<p;


end

