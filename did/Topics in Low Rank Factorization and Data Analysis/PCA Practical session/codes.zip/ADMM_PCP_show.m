%% the 65 images have size 96x84 
X = preprocessing(96,84);


% llam = 1/sqrt(size(X,2));
llam = .1/sqrt(size(X,2));
% llam = .01/sqrt(size(X,2));

mu = size(X,1)*size(X,2)/(4*norm(X(:),1));

[L,E,Lam] = ADMM_PCP(X,llam,mu);

E_est = []; L_est = [];
for i = 1:65
    E_est(:,:,i) = reshape(E(:,i),96,84);
    L_est(:,:,i) = reshape(L(:,i),96,84);
end
clf;
colormap(gray(100))
N = 10; i = 1;
for k = [3 4 14 18 20 24 32 43 46 50]
    subplot(3,N,i)
    imagesc(reshape(X(:,k),96,84))
    subplot(3,N,i+N)
    imagesc(reshape(L(:,k),96,84))
    subplot(3,N,i+2*N)
    imagesc(reshape(E(:,k),96,84))
    i = i+1;
end


 % imagesc(E_est(:,:,1))
  % imagesc(E_est(:,:,2))
   % imagesc(E_est(:,:,3))
    % imagesc(E_est(:,:,4)) 
