function [mu,U,Y] = PI_IPCA(X,W,k)
maxit = 10000; tol = .0001;

X(W==0) = 0;

Y = rand(k,size(X,2)); U = rand(size(X,1),k); mu = mean(X,2);
err = 2*norm(X-mu-U*Y); new_err = err/2;  i = 0;

while abs(err-new_err)/abs(err) > tol && i < maxit
    A = X-U*Y; A(W==0) = 0; mu = sum(A,2)./sum(W,2);
    A = X-mu; A(W==0) = 0; A = Y*A'; 
    for j = 1:size(X,1)
        R = Y*diag(W(j,:))*Y'; U(j,:) = (R\A(:,j))'; 
    end
    [U,~] = qr(U,"econ");
    A = X-mu; A(W==0) = 0; A = U'*A; 
    for j = 1:size(X,2)
        R = U'*diag(W(:,j))*U; Y(:,j) = R\A(:,j); 
    end
    err = new_err; new_err = norm(X-mu-U*Y); i = i+1;
end

mu = mu + mean(U*Y,2); Y = Y - mean(Y,2);

end