function [L,E,Lam] = ADMM_OPP(X,llam,mu)
maxit = 10000; tol = .0001;

E = zeros(size(X)); Lam = zeros(size(X)); 
% mu = size(X,1)*size(X,2)/(4*norm(X(:),1));
% llam = 1/sqrt(size(X,2));
augm_lap = mu*norm(X,'fro')^2; new_augm_lap = mu*norm(X,'fro')^2/2; i = 0;
while abs(augm_lap-new_augm_lap)/abs(augm_lap) > tol && i < maxit
    [U,S,V] = svd(Lam/mu + X - E,"econ");
    S = diag( max(0,diag(S)-1/mu) ); 
    L = U*S*V';
    A = Lam/mu + X - L; vA = vecnorm(A); E = zeros(size(X)); w = 1:size(X,2); 
    for j = w(vA>llam/mu)
            E(:,j) = A(:,j)*(1 - llam/(mu* vA(j))); 
    end
    Lam = Lam + mu*(X-L-E);
    i = i+1; augm_lap = new_augm_lap;
    new_augm_lap = norm(svd(L),1) + llam*sum(vecnorm(E)) + ...
       mu*norm(X-L-E,'fro')^2/2 + sum(sum(Lam.*(X-L-E)));
end

end