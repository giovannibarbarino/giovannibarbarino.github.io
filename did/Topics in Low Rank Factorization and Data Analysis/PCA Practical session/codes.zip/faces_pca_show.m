%% the 65 images have size 192x168 
X = preprocessing();
k = 9;
tic;
[mu,U,Y] = faces_pca(X,k);
t = toc
X_est = [];
for i = 1:k
    X_est(:,:,i) = reshape(U(:,i),192,168);
end
clf;
colormap(gray(100))
 % imagesc(reshape(mu,size(Xi,1),size(Xi,2)))
  imagesc(X_est(:,:,1))
  % imagesc(X_est(:,:,2))
   % imagesc(X_est(:,:,3))
    % imagesc(X_est(:,:,4))
