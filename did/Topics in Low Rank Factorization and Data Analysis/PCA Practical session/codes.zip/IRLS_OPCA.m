function [mu,U,Y,E] = IRLS_OPCA(X,k)
maxit = 10000; tol = .0001; eps = .5;

[mu,U,Y] = faces_pca(X,k); W = ones(size(X));
err = 2*norm(X-mu-U*Y); new_err = err/2;  i = 0;

while abs(err-new_err)/abs(err) > tol && i < maxit
    E = X-mu-U*Y; vE = vecnorm(E);
    W = ones(size(X,1),1)*(eps^2./(vE.^2 + eps^2));
    A = (X-U*Y).*W; mu = sum(A,2)./sum(W,2);
    A = (X-mu).*W; A = Y*A'; 
    for j = 1:size(X,1)
        R = Y*diag(W(j,:))*Y'; U(j,:) = (R\A(:,j))'; 
    end
    [U,~] = qr(U,"econ");
    A = (X-mu).*W; A = U'*A; 
    for j = 1:size(X,2)
        R = U'*diag(W(:,j))*U; Y(:,j) = R\A(:,j); 
    end

    err = new_err; new_err = norm(X-mu-U*Y); i = i+1;
end

mu = mu + mean(U*Y,2); Y = Y - mean(Y,2); E = X-mu-U*Y; 

end