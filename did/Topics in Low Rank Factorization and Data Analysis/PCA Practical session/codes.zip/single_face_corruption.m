clf;

A = imread("yaleB17_P00A+000E+00.pgm");
 A = double(A)/255;

 A = A + 10*max(rand(size(A))-.8,0);
imagesc(A); % pause(1)

%%
llam = 1/sqrt(size(A,2));
mu = 1*size(A,1)*size(A,2)/(4*norm(A(:),1));
[L,E,Lam] = ADMM_PCP(A,llam,mu);

colormap(gray(100))
imagesc(L)
 

