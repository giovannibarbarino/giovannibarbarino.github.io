%% the 65 images have size 96x84 
X = preprocessing(96,84);

alp = .7; k = 9;
W = ones(size(X)); Waux = rand(size(X)) - alp; W(Waux<0) = 0;

[mu,U,Y] = PI_IPCA(X,W,k);
L = mu + U*Y;
X_est = []; L_est = [];
for i = 1:65
    X_est(:,:,i) = reshape(X(:,i),96,84);
    L_est(:,:,i) = reshape(L(:,i),96,84);
end
clf;
colormap(gray(100))
N = 7; i = 1;
for k = [3 4 14 18 20 24 32 ]
    subplot(2,N,i)
    imagesc(reshape(W(:,k),96,84).*reshape(X(:,k),96,84))
    subplot(2,N,i+N)
    imagesc(reshape(L(:,k),96,84))
    i = i+1;
end
