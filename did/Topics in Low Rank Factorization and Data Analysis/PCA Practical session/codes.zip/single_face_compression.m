clf;

A = imread("yaleB17_P00A+000E+00.pgm");
 A = double(A)/255; 
 mu = mean(A,2);
 [U,S,V] = svd(A - mu);
% norm(U*S*V'-A)
 % imshow(A);

v = []; c = []; N=50;
for k =1:N
B = mu + U(:,1:k)*S(1:k,1:k)*V(:,1:k)';
subplot(2,2,1); imshow(B); 
subplot(2,2,3); imshow(A);
subplot(2,2,2);
v(k) = norm(B-A);
plot(1:k,v); ax = gca; 
ax.XLim=[1,N]; ax.YLim=[0,v(1)];
subplot(2,2,4);
c(k) = k*(size(A,1) + size(A,2))/(size(A,1)*size(A,2));
% plot(1:k,c+v/50); ax = gca;
plot(1:k,c); ax = gca;
ax.XLim=[1,N]; ax.YLim=[0,1];
pause(.5);
end
