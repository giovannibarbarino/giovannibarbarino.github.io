%% the 65 images have size 96x84 
X = preprocessing(96,84);

P = './yaleB01_outlier/';
D = dir(fullfile(P,'*.jpg'));
Xo = [];
for i = 1:size(D,1)
    Xi = imread(fullfile(P,D(i).name));
    Xi = imresize(Xi,[96 84]);
    Xo(:,i) = double(Xi(:))/255;
end


gam = .1; Ni = size(X,2);
No = floor(gam*Ni/(1-gam));
X = [X Xo(:,1:No)];
% p = randperm(size(X,2)); X = X(:,p);

k = 4;

[mu,U,Y,E] = IRLS_RPCA(X,k);
vE = vecnorm(E);

clf;
plot(1:Ni, vE(1:Ni),'b');
hold on;
plot(Ni+1:Ni+No, vE(Ni+1:Ni+No),'r');
