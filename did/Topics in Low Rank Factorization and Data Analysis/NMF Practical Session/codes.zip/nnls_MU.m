function [H,WtW,WtX] = nnls_MU(X,W,H,options)

% Computes an approximate solution of the following nonnegative least
% squares problem (NNLS)
%
%           min_{H >= 0} ||X-WH||_F^2
%
% using multiplicative updates.  
%
% 
% + options.epsilon gives lower bound on the entries of H for better
%   numerical performance; 
%     default = 2^(-52) (Matlab epsilon machine)

if nargin <= 3
    options = [];
end
if ~isfield(options,'delta')
    options.delta = 1e-6; % Stopping condition depending on evolution of the iterate V:
    % Stop if ||V^{k}-V^{k+1}||_F <= delta * ||V^{0}-V^{1}||_F
    % where V^{k} is the kth iterate.
end
if ~isfield(options,'inneriter')
    options.inneriter = 20;
end
if ~isfield(options,'epsilon')
    options.epsilon = 2^(-52);
end

W = full(W); 
[m,n] = size(X);
[m,r] = size(W);
WtW = W'*W;
WtX = W'*X;

if min(X(:)) < 0
    warning('The matrix X should be nonnegative. Zero entries set to 0.'); 
    X = max(X, 0); 
end
if min(W(:)) < 0
    warning('The matrix W should be nonnegative. Zero entries set to 0.'); 
    W = max(W, 0); 
end
if min(H(:)) <= 0
    H(H<=0) = 0.001*max(H(:)); % This is important for MU to be able to modify such entries
end

eps0 = 0; cnt = 1; eps = 1;
while eps >= options.delta*eps0 && cnt <= options.inneriter %Maximum number of iterations
    Hp = H;
    H = max(options.epsilon, H.*(WtX)./(WtW*H));
    if cnt == 1
        eps0 = norm(Hp-H,'fro');
    end
    eps = norm(Hp-H,'fro');
    cnt = cnt + 1;
end
end % of function nnlsMU