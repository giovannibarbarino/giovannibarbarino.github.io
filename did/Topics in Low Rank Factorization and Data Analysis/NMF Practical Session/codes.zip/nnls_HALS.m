function [H,WtW,WtX] = nnls_HALS(X,W,H,options)

% Computes an approximate solution of the following nonnegative least
% squares problem (NNLS)
%
%           min_{H >= 0} ||X-WH||_F^2
%
% with an exact block-coordinate descent scheme.
%

if nargin <= 3
    options = [];
end
if ~isfield(options,'delta')
    options.delta = 1e-6; % Stopping condition depending on evolution of the iterate V:
    % Stop if ||V^{k}-V^{k+1}||_F <= delta * ||V^{0}-V^{1}||_F
    % where V^{k} is the kth iterate.
end
if ~isfield(options,'inneriter')
    options.inneriter = 100;
end

W = full(W); 
[m,n] = size(X);
[m,r] = size(W);
WtW = W'*W;
WtX = W'*X;

if min(X(:)) < 0
    warning('The matrix X should be nonnegative. Zero entries set to 0.'); 
    X = max(X, 0); 
end
if min(W(:)) < 0
    warning('The matrix W should be nonnegative. Zero entries set to 0.'); 
    W = max(W, 0); 
end

eps0 = 0; cnt = 1; epsi = 1;
while epsi >= (options.delta)^2*eps0 && cnt <= options.inneriter %Maximum number of iterations
    nodelta = 0; 
    for k = 1 : r
        deltaH = max((WtX(k,:)-WtW(k,:)*H)/(WtW(k,k)+1e-16),-H(k,:));
        H(k,:) = H(k,:) + deltaH;
        % Last two line equivalent to the HALS update: 
        % H(k,:) = max(0, (WtX(k,:)-WtW(k,:)*H+WtW(k,k)*H(k,:))/(WtW(k,k)+1e-16) ) ; 
        nodelta = nodelta + deltaH*deltaH'; % used to compute norm(V0-V,'fro')^2;
        if H(k,:) == 0 % safety procedure 
            H(k,:) = 1e-16; 
        end 
    end
    if cnt == 1
        eps0 = nodelta;
    end
    epsi = nodelta;
    cnt = cnt + 1;
end

end % of function nnlsHALSupdt