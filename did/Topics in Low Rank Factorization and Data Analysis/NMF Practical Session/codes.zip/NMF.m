function [U,V,err,T] = NMF(M,U,V,options)
if nargin <= 3
    options = [];
end
if ~isfield(options,'display')
    options.display = 1; 
end
%% Parameters of NMF algorithm
if ~isfield(options,'maxiter')
    options.maxiter = 500; 
end
if ~isfield(options,'algo')
    options.algo = "HALS"; 
end
% Parameters for the number of inner iterations: delta and alpha
if ~isfield(options,'delta')
    options.delta = 0.1; 
end
%% Precomputations
nM = norm(M,'fro'); 
err(1) = norm(M-U*V,'fro') / nM; 
T(1) = 0;

for i = 2:options.maxiter
    tic;
    if options.algo == "MU"
        [V,~,~] = nnls_MU(M,U,V,options); % Update of V
        [Ut,VVt,VMt] = nnls_MU(M',V',U',options); % Update of U
    elseif options.algo == "HALS"
        [V,~,~] = nnls_HALS(M,U,V,options); % Update of V
        [Ut,VVt,VMt] = nnls_HALS(M',V',U',options); % Update of U
    end
    U = Ut';
    MVt = VMt';
    tt = toc;
    T(i) = tt + T(i-1);
    err(i) = abs(sqrt( nM^2 - 2*sum(sum( MVt.*U ) ) + sum( sum( VVt.*(Ut*U) ) ) )) / nM;
    % The line above is equivalent to err(i) = norm(M-U*V) / nM;
end
end

