%%%%%%%%% https://bit.ly/classNMF %%%%%%%%%%
%% Task 1.
close all
clear all
[m, n, r] = deal(100, 1000, 10);
[U,V] = deal(rand(m,r),rand(r,n));
M = U*V;
options.algo = 'MU';
options.maxiter=1000;
[~,~,err] = NMF(M,rand(m,r),rand(r,n),options);
figure('Position',[0 0 400 200]);
semilogy(err,'LineWidth',2)
title('Error evolution')
xlabel('Iterations')
ylabel('||M-UV||_F/||M||_F')

%% Task 2.
close all
clear all
load("CBCL.mat")
[m,n] = size(X);
r = 49;
options.algo = 'MU';
options.maxiter = 200; 
[U,V,err] = NMF(X,rand(m,r),rand(r,n),options);
figure('Position',[0 0 400 200]);
semilogy(err,'LineWidth',2)
title('Error evolution')
xlabel('Iterations')
ylabel('||M-UV||_F/||M||_F')
xlim([0 100])
ylim([min(err)-0.02 1])
affichage(U,7,19,19);

%% Task 3.
close all
clear all
load("tdt2_top30.mat")
X = X';
[m,n] = size(X);
r = 20;
options.algo = 'MU';
options.maxiter = 50; 
[U,V,err] = NMF(X,rand(m,r),rand(r,n),options);
figure('Position',[0 0 400 200]);
semilogy(err,'LineWidth',2)
title('Error evolution')
xlabel('Iterations')
ylabel('||M-UV||_F/||M||_F')
ylim([min(err)-0.02 1])
top10 = repmat("",10,r);
for j = 1:r
    [~,temp] = sort(U(:,j),'descend');
    top10(:,j) = string(words(temp(1:10)));
end
top10

%% Task 5.
close all
clear all
load("CBCL.mat")
[m,n] = size(X);
r = 49;
options.maxiter = 100; 
Uinit = rand(m,r);
Vinit = rand(r,n);
% MU
options.algo = 'MU';
[U,V,errMU,TMU] = NMF(X,Uinit,Vinit,options);
% HALS
options.algo = 'HALS';
[U,V,errHALS,THALS] = NMF(X,Uinit,Vinit,options);

figure('Position',[0 0 400 200])
semilogy(errMU,'LineWidth',2)
hold on
semilogy(errHALS,'LineWidth',2)
title('Error evolution on CBCL by iteration')
xlabel('Iterations')
ylabel('||M-UV||_F/||M||_F')
legend(["MU" "HALS"])
ylim([min([errMU errHALS])-0.02 1])



%%%%%%%%%%%%%%%%%%

figure('Position',[0 0 400 200])
semilogy(TMU,errMU,'LineWidth',2)
hold on
semilogy(THALS,errHALS,'LineWidth',2)
title('Error evolution on CBCL by time')
xlabel('Time')
ylabel('||M-UV||_F/||M||_F')
legend(["MU" "HALS"])
ylim([min([errMU errHALS])-0.02 1])

%%%%%%%%%%%%%%%%%%%%%

load("tdt2_top30.mat")
[m,n] = size(X);
r = 30;
options.maxiter = 50; 
Uinit = rand(m,r);
Vinit = rand(r,n);
% MU
options.algo = 'MU';
[U,V,errMU,TMU] = NMF(X,Uinit,Vinit,options);
% HALS
options.algo = 'HALS';
[U,V,errHALS,THALS] = NMF(X,Uinit,Vinit,options);

figure('Position',[0 0 400 200])
%semilogy(errMU,'LineWidth',2)
semilogy(TMU,errMU,'LineWidth',2)
hold on
%semilogy(errHALS,'LineWidth',2)
semilogy(THALS,errHALS,'LineWidth',2)
title('Error evolution on tdt2 by time')
%xlabel('Iterations')
xlabel('Time')
ylabel('||M-UV||_F/||M||_F')
legend(["MU" "HALS"])
ylim([min([errMU errHALS])-0.02 1])
