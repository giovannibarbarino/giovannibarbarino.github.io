function plcut(fun,a,b,tol)

% servono funzioni univariate differenziabili convesse

clf;
hold on;

fplot(fun,[a,b], 200);

pause; 
i=0;
x0 = a;
d = Inf;
f = @(x) (-Inf);

while(d>tol)

    plot(x0,fun(x0),'r.');
    plot(x0,f(x0),'b.');
    s = gradient(fun,x0,0.0000001);
    d = fun(x0) - f(x0)
    fplot(@(x) fun(x0)+s*(x-x0) ,[a,b], 200);
    pause;
    f = @(x) ( max( f(x), fun(x0)+s*(x-x0) )   );
    x0 = fminbnd (f, a, b)
    i++

endwhile








endfunction
