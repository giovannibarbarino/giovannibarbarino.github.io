function s = bl_box(f, y)

% ritorna un sottogradiente della funzione f al punto y
% si suppone f convessa
% funziona come gradient: è esattamente differenze centrate..


s(1) = ( f(y+1.e-10) - f(y) ) * 1.e+10; 
s(2) = ( - f(y-1.e-10) + f(y) ) * 1.e+10;

s = (s(1) + s(2)) / 2;














endfunction
