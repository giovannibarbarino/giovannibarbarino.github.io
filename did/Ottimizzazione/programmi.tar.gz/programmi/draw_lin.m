function draw_lin( f, varphi, a, b, y, x, mu)




figure(2);
clf;
fplot(f,[a,b], 200, 'k');

t = linspace(a,b,1000);
plot(t,f(t), 'k', 'LineWidth',1);

hold on;

g = @(x) (varphi(x));

  %ffun = @(z) ( max(varphi(z)) + 0.5*mu*norm(z-x)^2 );
  
  %h=(b-a)/100;
  %for  i=a:h:b
  %  plot(i,ffun(i), 'g.');
  %endfor
    %fplot(ffun,[a,b], 200, 'g');



fplot(g,[a,b], 200, 'r');
legend("off");

plot(y,max(varphi(y)),'b.');




figure(1);







endfunction
