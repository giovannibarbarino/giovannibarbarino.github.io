function x0 = min_prob( f, varphi, xk , a, b, mu )



%if length(mu) == 0

%    ffun = @(y) ( max(varphi(y)) );
%    x0 = fminbnd (ffun, a, b);

%endif


%if length(mu) != 0

   % ffun = @(y) ( max(varphi(y)) + 0.5*mu*norm(y-xk)^2 );
   % y0 = fminbnd (ffun, a, b);
    
    
    
    %varphi
    
     l = length(varphi(xk));
    ei = f(xk)*ones(1,l) - varphi(xk);
    si = varphi(xk+1) - varphi(xk);
    
    
if (mu!=0)    
   
    

    
    options = optimset("MaxIter", 1000);
    
    xin = [
    f(xk)
    xk ];
    
    H = [
    0 0
    0 mu ];
    
    q = [
    1
    -xk*mu ];
    
    A_in (1:l,1) = ones(l,1);
    A_in (1:l,2) = -si';
    A_in (l+1:l+2,1) = zeros(2,1);
    A_in (l+1:l+2,2) = [1;-1];
    
    A_lb (1:l,1) = f(xk)*ones(l,1) - ei' - xk*si';
    A_lb (l+1:l+2,1) = [a;-b];
    
    
    
    [alfa, obj, info] = qp (xin , H, q, [], [], [], [], A_lb, A_in, [] ,options);
    
    x0 = alfa(2);
else

    c = [1;0];
    A (1:l,1) = ones(l,1);
    A (1:l,2) = -si';
    
    bb (1:l,1) = f(xk)*ones(l,1) - ei' - xk*si';
    
    lb = [-Inf;a];
    ub = [max(varphi(xk)),b];
    
    for i=1:l
        ctype(i) = "L";
    endfor
    
    vartype = ["C";"C"];
    sense=1;
    
    
 [xopt, fmin, errnum, extra] = glpk (c, A, bb, lb, ub, ctype, vartype);


    x0 = xopt(2);
endif

%figure(3);
%clf;
%hold on;
%h = (b-a)/100;
%for i = a : h : b
%    plot (i, ffun(i), 'g.');
%endfor
%plot(x0, ffun(x0), 'b.');
%plot(y0, ffun(y0), 'r.');


%figure(1);




%endif

















endfunction
