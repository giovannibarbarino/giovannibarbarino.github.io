function [newmod,mu] = mod_update ( varphi, f, delta, sn, xn, ynew, xv, mu, nmax)


l = length(varphi(ynew));



if l < nmax || abs(mu)<=1.e-16 

    newmod = @(y) [varphi(y), f(ynew) + sn*(y-ynew)];        
        
else

    ei = f(xv)*ones(1,l) - varphi(xv);
    si = varphi(xv+1) - varphi(xv);
    
    
    options = optimset("MaxIter", 100);
    
    
    
    %zeros(l,1) , si'*si, mu*ei', ones(1,l), 1, zeros(l,1), ones(l,1),options
    
    
    
    
    [alfa, obj, info] = qp (ones(l,1)./l , si'*si, mu*ei', ones(1,l), 1, zeros(l,1), ones(l,1),options);
    
    k=0;
    varphi = @(y) [];
    for i=1:l
        if alfa(i)>1.e-16
            varphi = @(y) [varphi(y), f(xv) - ei(i) + si(i)*(y-xv)];  
            k=k+1;
        endif
    endfor
    
     
    
   
    if(k==l)
        varphi = @(y) [];
    
        for i=3:l
            varphi = @(y) [varphi(y), f(xv) - ei(i) + si(i)*(y-xv)];  
        endfor
        
        ssn = mu*(xv-ynew);
        varphi = @(y) [varphi(y), f(xv) - (delta + ssn^2/(2*mu)) + ssn*(y-xv)];  
        
    endif
    
    
    newmod = @(y) [varphi(y), f(ynew) + sn*(y-ynew)]; 
    
endif



if mu != 0 && ynew == xn

    sv = mu * (xv - ynew);
    dif = (ynew-xv)/(sn-sv);
    if (dif > 0)
        mu = (mu^(-1) + dif )^(-1);
    endif 

endif 
















endfunction
