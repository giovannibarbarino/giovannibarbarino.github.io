function dd = err_app( f, varphi, xk, ynew, mu)

%l = length(varphi(xk));



    ffun = @(x) ( max(varphi(x)) );
    if mu==0
        dd = f(ynew) - ffun(ynew);
    else
        dd = f(xk) - ffun(ynew) - .5*mu*norm(ynew-xk)^2;
    endif




















endfunction
