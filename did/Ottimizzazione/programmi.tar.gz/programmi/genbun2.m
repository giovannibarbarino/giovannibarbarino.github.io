function genbun2(f,a,b,m,tol,mu,nmax,tole)


% funziona per funzioni f convesse su [a,b] e trova il minimo
% genbun(f,a,b,m,tol,mu,nmax,tole)
% mu rimane costante
% nota: se mu è zero, allora nmax non è necessario


clf;
fplot(f,[a,b], 200, 'k');



hold on;

l=nargin();

if l < 8
    tole = 0; 
endif
if l < 7
    nmax = Inf; 
endif
if l < 6
    mu = 0;
endif
if l < 5
    tol = 1.e-10;
endif
if l < 4
    m = 0;
endif
if l < 3
    b = Inf;
endif
if l < 2
    a = -Inf;
endif


if tole!=0
    tols = tol - tole;
endif
delta = Inf;
if a == -Inf
    y(1) = min(b,0)-1;
else
    y(1) = a;
endif
x(1) = y(1);
k=1;



s = bl_box(f, y(1));

varphi = @(y) ( f(x(1)) + s*(y-x(1)) );


while k<1000

 y(k+1) = min_prob( f, varphi, x(k), a, b, mu );
 
 draw_lin( f, varphi, a, b, y(k+1), x(k), mu); 
 pause
 

 
 
 
 sn = bl_box(f,y(k+1));
 if (abs(sn)<1.e-16)
    k=k+1;
    x(k)=y(k);
    plot(x(k),f(x(k)),'r.');
     disp("uscita per sottogradiente piccolo");
    break;
 endif
 
 delta = err_app( f, varphi, x(k), y(k+1), mu );
 
 if f(x(k)) - f(y(k+1)) >= m*delta
    x(k+1) = y(k+1);
    plot(x(k+1),max(varphi(x(k+1))),'r.');
 else 
    x(k+1) = x(k);
    plot(y(k+1),max(varphi(y(k+1))),'b.');
 endif
 
 
  
 if mu!=0 && tole!=0
    ssn = mu*(x(k)-y(k+1));
    ve = delta - ssn^2/(2*mu);
    if ve<=tole && ssn^2<=tols
        k=k+1;
        break;
    endif
 else 
    if delta<=tol
        k=k+1;
        break;
    endif
 endif
 

 [varphi] = mod_update ( varphi, f, delta, sn, x(k+1), y(k+1), x(k), mu, nmax);
 
 
k = k+1;

endwhile

y = y(k)
x = x(k)
k







endfunction
