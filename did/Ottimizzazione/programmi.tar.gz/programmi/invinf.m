function invinf

n=10;
A=diag(3*ones(1,n))+diag(-1*ones(1,n-1),1)+diag(-2*ones(1,n-1),-1);

x0=n;
nor(n)=norm(A^(-1),Inf);
y0=nor(n);



for n=11:300

A=diag(3*ones(1,n))+diag(-1*ones(1,n-1),1)+diag(-2*ones(1,n-1),-1);

nor(n)=norm(A^(-1),Inf);


    
endfor

x1=n;
y1=nor(n);

%(x1-x0)/(y1-y0)

plot(nor);


gradient(nor)




end
